# Herval.Emarsys.Sdk

## Descrição
A `Herval.Emarsys.Sdk` é uma biblioteca responsável pela integração com a API da Emarsys, permitindo o envio de e-mails, eventos, criação de contatos, produtos e envio de dados de vendas de forma simplificada. Esta SDK foi projetada para ser utilizada em projetos .NET, disponível para todos os times de desenvolvimento.

## Novas Funcionalidades
- **Envio de Eventos**: Permite disparar eventos customizados na Emarsys, com suporte a anexos e variáveis dinâmicas.
- **Criação de Contatos**: Possibilita criar contatos diretamente na base da Emarsys, com todos os dados pessoais e de negócio.
- **Envio de Dados de Vendas**: Suporte ao envio de arquivos CSV de vendas para integração com a Emarsys (via serviço dedicado).
- **Cadastro de Produtos**: Permite cadastrar produtos na base da Emarsys para campanhas e segmentações.

## Instalação
Para utilizar a SDK, adicione a referência ao projeto no seu arquivo `.csproj` ou instale o pacote via NuGet (se disponível).

### Exemplo de instalação via NuGet
```bash
Install-Package Herval.Emarsys.Sdk
```

## Configuração
Antes de utilizar a SDK, é necessário configurar os endpoints da API Emarsys no seu arquivo de configuração `appsettings.json`.

### Exemplo de configuração
```json
{
  "ApiEmarsys": {
    "Endpoint": "https://api.emarsys.net/",
    "EndpointVendas": "https://api.emarsys.net/" (Se utilizado servico de Vendas)
  }
}
```

Adicione também os serviços necessários no seu projeto:

```csharp
public static class ApiConfiguration
{
    public static void AddApiServices(this IServiceCollection services, IConfiguration configuration)
    {
        // Adiciona serviço de eventos
        services.AddEmarsysEventoService(configuration);
        
        // Adiciona serviço de contatos
        services.AddEmarsysContatoService(configuration);
        
        // Adiciona serviço de vendas
        services.AddEmarsysVendaService(configuration);
        
        // Adiciona serviço de produtos
        services.AddEmarsysProdutoService(configuration);
    }
}
```

## Como usar
Abaixo estão exemplos de como utilizar os principais recursos da SDK.

### Enviar um evento
Para disparar um evento customizado na Emarsys, utilize o método `EnviarEventoAsync`:

```csharp
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;

public class EventoService
{
    private readonly IEmarsysEventoService _emarsysEventoService;

    public EventoService(IEmarsysEventoService emarsysEventoService)
    {
        _emarsysEventoService = emarsysEventoService;
    }

    public async Task EnviarEventoAsync(CancellationToken cancellationToken)
    {
        var eventoDto = new EnviarEventoDto
        {
            EventoId = "ID_DO_EVENTO",
            EmailDestinatario = "usuario@exemplo.com",
            DocumentoDestinatario = "DOCUMENTO_VALIDO", "QUANDO NAO HOUVER EMAIL"
            Dados = new Dictionary<string, string> { { "chave", "valor" } },
            Negocio = ENegocio.Exemplo,
            Anexos = new List<AnexoEmailDto>()
        };
        
        await _emarsysEventoService.EnviarEventoAsync(eventoDto, cancellationToken);
    }
}
```

### Criar um contato
Para criar um contato na base da Emarsys:

```csharp
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;
using Herval.ValueObjects.Objects;

public class ContatoService
{
    private readonly IEmarsysContatoService _emarsysContatoService;

    public ContatoService(IEmarsysContatoService emarsysContatoService)
    {
        _emarsysContatoService = emarsysContatoService;
    }

    public async Task CriarContatoAsync(CancellationToken cancellationToken)
    {
        var criarContatoDto = new CriarContatoDto()
        {
            Negocio = ENegocio.HsConsorcio,
            Nome = "Joao",
            Sobrenome = "Teste",
            Email = "teste@herval.com.br",
            DataNascimento = new DateTime(1995, 9, 20),
            Genero = EGenero.Masculino,
            EstadoCivil = EEstadoCivil.Solteiro,
            Endereco = "Rua Teste",
            Cidade = "Porto Alegre",
            Estado = "RS",
            PaisOrigem = EPaisOrigem.Brasil,
            CEP = "91755110",
            Telefone = "5551912345678",
            Documento = "17506412403",
            DocumentoEstrangeiro = "1234567890"
        };

        await _emarsysContatoService.CriarContatoAsync(criarContatoDto, cancellationToken);
    }
}
```

### Atualizar um contato

Para atualizar um ou mais campos específicos do contato na base do Emarsys:

```csharp
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;
using Herval.ValueObjects.Objects;

public class ContatoService
{
    private readonly IEmarsysContatoService _emarsysContatoService;

    public ContatoService(IEmarsysContatoService emarsysContatoService)
    {
        _emarsysContatoService = emarsysContatoService;
    }

    public async Task AtualizarContatoAsync(CancellationToken cancellationToken)
    {
        var atualizarContatoDto = new AtualizarContatoDto()
        {
            Negocio = ENegocio.Taqi,
            Documento = "51912345678",
            Nome = "Vini",
            Sobrenome = "Silva",
            Email = "Teste123@hotmail.com",
            AceitaContatoWhatsApp = false,
        };

        await emarsysService.AtualizarContatoAsync(atualizarContatoDto, cancellationToken);
    }
}
```

### Criar um forms
Para criar um forms/lead na base da Emarsys:

```csharp
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;
using Herval.ValueObjects.Objects;

public class ContatoService
{
    private readonly IEmarsysContatoService _emarsysContatoService;

    public ContatoService(IEmarsysContatoService emarsysContatoService)
    {
        _emarsysContatoService = emarsysContatoService;
    }

    public async Task CriarFormsAsync(CancellationToken cancellationToken)
    {
        var criarFormsDto = new CriarFormsDto()
        {
            FormsId = "123456",
            Negocio = ENegocio.Iplace,
            // Escolha uma das formas de comunicação abaixo
            Documento = "17506412403",
            Email = "teste@gmail.com",
            Telefone = "51912345678"
        };

        await emarsysService.CriarFormsAsync(criarFormsDto, cancellationToken);
    }
}
```

### Enviar produtos
Para enviar produtos para a Emarsys:

```csharp
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;

public class ProdutoService
{
    private readonly IEmarsysProdutoService _emarsysProdutoService;

    public ProdutoService(IEmarsysProdutoService emarsysProdutoService)
    {
        _emarsysProdutoService = emarsysProdutoService;
    }

    public async Task EnviarProdutosAsync(CancellationToken cancellationToken)
    {
        var produtoDto = new ProdutoDto(
            item: "123",
            nome: "Produto Exemplo",
            link: "https://loja.exemplo.com/produto/123",
            imagemLink: "https://loja.exemplo.com/imagens/123.jpg",
            preco: 99.90M,
            categoria: "Categoria",
            disponivel: true,
            marca: "Marca",
            descricao: "Descrição do produto"
        );

        var enviarProdutoDto = new EnviarProdutoDto
        {
            Negocio = ENegocio.Herval,
            Produtos = new List<ProdutoDto> { produtoDto }
        };
        
        await _emarsysProdutoService.EnviarProdutoAsync(enviarProdutoDto, cancellationToken);
    }
}
```

### Enviar dados de vendas
Para enviar vendas para a Emarsys:

```csharp
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;

public class VendaService
{
    private readonly IEmarsysVendaService _emarsysVendaService;

    public VendaService(IEmarsysVendaService emarsysVendaService)
    {
        _emarsysVendaService = emarsysVendaService;
    }

    public async Task EnviarVendaAsync(CancellationToken cancellationToken)
    {
        var vendaDto = new VendaDto(
            origem: "MARKET",
            orderId: "112343",
            dataVenda: DateTime.Parse("2025-04-06T14:02:00Z"),
            moeda: "BRL",
            cliente: "leonardo.dsilva@herval.com.br",
            documento: "04220384073",
            item: "teste-leo-nike-1",
            precoOriginal: 20,
            preco: 20,
            quantidade: 1,
            cupom: "PROMO2025",
            categoriaPromocao: "Promoção de Verão",
            matriculaVendedor: "123456",
            nomeVendedor: "Leonardo Silva",
            nomeLoja: "Loja Teste",
            cidadeLoja: "Porto Alegre",
            estadoLoja: "RS",
            numeroNotaFiscal: "123456789",
            tipoPagamento: "Cartão de Crédito"
        );

        var enviarVendaDto = new EnviarVendaDto
        {
            Negocio = ENegocio.Herval,
            Vendas = new List<VendaDto> { vendaDto }
        };
        
        await _emarsysVendaService.EnviarVendaAsync(enviarVendaDto, cancellationToken);
    }
}
```

## Estrutura dos objetos DTO

### EnviarEventoDto
- **EventoId**: ID do evento na Emarsys.
- **EmailDestinatario**: E-mail do destinatário.
- **Identificacao**: Identificador alternativo para envio.
- **Dados**: Dicionário de variáveis customizadas.
- **Negocio**: Enum para identificar o negócio.
- **Anexos**: Lista de anexos (nome e base64).

### CriarContatoDto
- **Negocio**: Enum do negócio.
- **Nome/Sobrenome**: Dados pessoais.
- **Email**: Objeto Email do contato.
- **DataNascimento**: Data de nascimento.
- **Genero/EstadoCivil**: Dados pessoais.
- **Endereco/Cidade/Estado/CEP**: Endereço completo.
- **PaisOrigem**: País de origem do contato.
- **Telefone/Documento**: Dados de contato (objetos ValueObjects).

### CriarFormsDto
- **FormId**: Id do Form no emarsys
- **Negocio**: Enum do negócio.
- **Email**: Objeto Email do contato (objetos ValueObjects).
- **Telefone**: Objeto Telefone (objetos ValueObjects).
- **Documento**: Objeto Documento (objetos ValueObjects).

### ProdutoDto
- **Item**: Código do produto.
- **Nome**: Nome do produto.
- **Link**: URL do produto.
- **ImagemLink**: URL da imagem do produto.
- **Preco**: Preço do produto.
- **Categoria**: Categoria do produto.
- **Disponivel**: Disponibilidade do produto.
- **Marca**: Marca do produto.
- **Descricao**: Descrição do produto.

### EnviarProdutoDto
- **Negocio**: Enum do negócio.
- **Produtos**: Lista de produtos a serem enviados.

### EnviarVendaDto
- **Negocio**: Enum do negócio.
- **Vendas**: Lista de vendas a serem enviados..

## Tratamento de erros
A SDK utiliza o `INotificationContext` para gerenciar notificações e erros. Certifique-se de verificar as notificações após realizar operações.

#### Exemplo de verificação de notificações
```csharp
if (_notificationContext.HasNotifications)
{
    // Tratamento caso haja notificações
}
```