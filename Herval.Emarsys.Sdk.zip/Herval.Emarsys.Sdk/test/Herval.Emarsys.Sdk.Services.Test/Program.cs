﻿using Herval.Emarsys.Sdk.Interfaces;
using Herval.Emarsys.Sdk.IoC;
using Herval.Emarsys.Sdk.Services.Test;
using Herval.Emarsys.Sdk.Dtos;
using Herval.Graylog.Extensions;
using Herval.Notifications.Contexts;
using Herval.Notifications.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

var configuration = new ConfigurationBuilder()
    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
    .Build() ?? throw new Exception("Erro ao carregar arquivo de configuração");

var consoleAssembly = Assembly.GetExecutingAssembly();

var serviceProvider = new ServiceCollection()
    .AddSingleton<IConfiguration>(configuration)
    .AddScoped<INotificationContext, NotificationContext>()
    .AddHttpContextAccessor()
    .AddEmarsysEventoService(configuration)
    .AddEmarsysVendaService<VendaDto>(configuration)
    .AddEmarsysVendaService<VendaDto>(configuration)
    .AddEmarsysProdutoService(configuration)
    .AddEmarsysContatoService(configuration);


serviceProvider.AddGraylog(consoleAssembly);

var services = serviceProvider.BuildServiceProvider();

var cancellationToken = new CancellationTokenSource().Token;
var notificationContext = services.GetRequiredService<INotificationContext>();
var emarsysContatoService = services.GetRequiredService<IEmarsysContatoService>();
var emarsysEventoService = services.GetRequiredService<IEmarsysEventoService>();
var emarsysVendaService = services.GetRequiredService<IEmarsysVendaService>();
var emarsysProdutoService = services.GetRequiredService<IEmarsysProdutoService>();


//var produtoExporter = new CsvProdutoExporter();
//var vendaExporter = new CsvVendaExporter();

// Criar o conversor
//var conversor = new EmarsysFileConverter(produtoExporter, vendaExporter);

// Converter arquivo de vendas
//conversor.ConverterArquivoVendas(@"C:\Users\leonardo.dsilva\OneDrive - Grupo Herval\Documents\Vendas\iplace_2022_1.csv", @"C:\Users\leonardo.dsilva\OneDrive - Grupo Herval\Documents\Vendas\iplace_2022_1_emarsys.csv");

await TesteFactory.EnvioEventoAsync(emarsysEventoService, cancellationToken);

await TesteFactory.CriarContatoAsync(emarsysContatoService, cancellationToken);

await TesteFactory.AtualizarContatoAsync(emarsysContatoService, cancellationToken);

await TesteFactory.CriarFormsAsync(emarsysContatoService, cancellationToken);

await TesteFactory.EnvioProdutoAsync(emarsysProdutoService, cancellationToken);

await TesteFactory.EnvioVendaAsync(emarsysVendaService, cancellationToken);

Console.WriteLine($"Hello, World! {notificationContext.HasNotifications}");



