﻿using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Enums;
using Herval.Emarsys.Sdk.Interfaces;

namespace Herval.Emarsys.Sdk.Services.Test
{
    public static class TesteFactory
    {
        public static async Task CriarContatoAsync(IEmarsysContatoService emarsysService, CancellationToken cancellationToken)
        {
            var criarContatoDto = new EnviarContatoDto<CriarContatoHervalDto>()
            {
                Negocio = ENegocio.Herval,
                Contatos = new List<CriarContatoHervalDto>
                {
                    new()
                    {
                        Nome = "Julia",
                        Sobrenome = "Espinosa",
                        Email = "juana.espinosa@zenital.co",
                        DataNascimento = new DateTime(1995, 9, 20),
                        Genero = EGeneroContato.Feminino,
                        EstadoCivil = EEstadoCivilContato.Solteiro,
                        Endereco = "Rua Teste",
                        Cidade = "Porto Alegre",
                        Estado = "RS",
                        PaisOrigem = EPaisOrigemContato.Brasil,
                        CEP = "91755110",
                        Telefone = "5551912345678",
                        Documento = "36218889181",
                        DocumentoEstrangeiro = "1234567890"
                    }
                }
            };

            await emarsysService.CriarContatoAsync<CriarContatoHervalDto>(criarContatoDto, cancellationToken);
        }

        public static async Task AtualizarContatoAsync(IEmarsysContatoService emarsysService, CancellationToken cancellationToken)
        {
            var atualizarContatoDto = new AtualizarContatoDto()
            {
                Negocio = ENegocio.Taqi,
                Documento = "51912345678",
                Nome = "Vini",
                Sobrenome = "Silva",
                Email = "Teste123@hotmail.com",
                AceitaContatoWhatsApp = false,
            };

            await emarsysService.AtualizarContatoAsync(atualizarContatoDto, cancellationToken);
        }

        public static async Task CriarFormsAsync(IEmarsysContatoService emarsysService, CancellationToken cancellationToken)
        {
            var criarFormsDto = new CriarFormsDto()
            {
                FormsId = "123456",
                Negocio = ENegocio.HsConsorcio,
                Documento = "17506412403",
                Email = "teste@gmail.com",
                Telefone = "51912345678"
            };

            await emarsysService.CriarFormsAsync(criarFormsDto, cancellationToken);
        }

        public static async Task EnvioEmailAsync(IEmarsysEventoService emarsysService, CancellationToken cancellationToken)
        {
            var dados = new Dictionary<string, string>();

            var enviarEvento = new EnviarEventoDto
            {
                EventoId = "126338",
                EmailDestinatario = "guilherme.pienegonda@herval.com.br",
                Negocio = ENegocio.Iplace,
                Dados = dados,
            };

            await emarsysService.EnviarEventoAsync(enviarEvento, cancellationToken);
        }

        public static async Task EnvioEventoAsync(IEmarsysEventoService emarsysService, CancellationToken cancellationToken)
        {
            var dados = new Dictionary<string, string>
            {
                { "event_date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") }
            };

            var enviarEvento = new EnviarEventoDto
            {
                EventoId = "2457",
                DocumentoDestinatario = "5551991662208",
                //EmailDestinatario = "leonardo.dsilva@herval.com.br",
                Negocio = ENegocio.Herval,
                Dados = dados,
            };

            await emarsysService.EnviarEventoAsync(enviarEvento, cancellationToken);
        }

        public static async Task EnvioVendaAsync(IEmarsysVendaService emarsysVendaService, CancellationToken cancellationToken)
        {
            var enviarVendaDto = new EnviarVendaDto<VendaDto>
            {
                Negocio = ENegocio.Iplace,
                Vendas = new List<VendaDto>
                {
                    new(
                        origem: "MARKET",
                        orderId: "112343",
                        dataVenda: DateTime.Parse("2025-04-06T14:02:00Z"),
                        moeda: "BR",
                        cliente: "leonardo.dsilva@herval.com.br",
                        documento: "04220384073",
                        item: "teste-leo-nike-1",
                        precoOriginal: 20,
                        preco: 20,
                        quantidade: 1,
                        cupom: "PROMO2025",
                        categoriaPromocao: "Promoção de Verão",
                        matriculaVendedor: "123456",
                        nomeVendedor: "Leonardo Silva",
                        nomeLoja: "Loja Teste",
                        cidadeLoja: "Porto Alegre",
                        estadoLoja: "RS",
                        numeroNotaFiscal: "123456789",
                        tipoPagamento: "Cartão de Crédito",
                        pedidoEcommerceId: "PEDIDO123456",
                        multimeios: "multi"
                    )
                }
            };

            await emarsysVendaService.EnviarVendaAsync(enviarVendaDto, cancellationToken);
        }

        public static async Task EnvioProdutoAsync(IEmarsysProdutoService emarsysProdutoService, CancellationToken cancellationToken)
        {
            var enviarProdutoDto = new EnviarProdutoDto
            {
                Negocio = ENegocio.HsConsorcio,
                Produtos = new List<ProdutoDto>
                {
                    new ProdutoDto(
                        item: "produto-simples-1",
                        nome: "Produto Simples",
                        link: "https://www.herval.com.br/produto/produto-simples-1",
                        imagemLink: "https://www.herval.com.br/imagem/produto-simples-1.jpg",
                        preco: 99.99m,
                        categoria: "Categoria Simples",
                        disponivel: true,
                        marca: "Marca Simples",
                        descricao: "Descrição simples do produto."
                    ),
                    new ProdutoDto(
                        item: "teste-leo-nike-1",
                        nome: "Nike Air Max",
                        link: "https://www.herval.com.br/produto/teste-leo-nike-1",
                        imagemLink: "https://www.herval.com.br/imagem/teste-leo-nike-1.jpg",
                        preco: 199.99m,
                        categoria: "Calçados",
                        disponivel: true,
                        marca: "Nike",
                        descricao: "Tênis Nike Air Max, conforto e estilo para o seu dia a dia.",
                        zoomImagemLink: "https://www.herval.com.br/imagem/zoom/teste-leo-nike-1.jpg",
                        cor: "Preto",
                        msrp: 249.99m,
                        categoriaIdNivel3: "123",
                        categoriaNomeNivel3: "Tênis Esportivo",
                        categoriaIdNivel2: "12",
                        categoriaNomeNivel2: "Tênis",
                        categoriaIdNivel1: "1",
                        categoriaNomeNivel1: "Calçados",
                        precoDesconto: 179.99m,
                        numeroFornecedor: "NK-AMAX-001",
                        numeroFornecedor2: "NK-AMAX-002",
                        precoLista: 199.99m,
                        precoVenda: 179.99m,
                        numeroParcelas: 10,
                        precoParcela: 19.99m,
                        valorParcela: 19.99m,
                        estoque: 50.00m
                    )
                }
            };

            await emarsysProdutoService.EnviarProdutoAsync(enviarProdutoDto, cancellationToken);
        }
    }
}
