using System.Text.Json.Serialization;

namespace Herval.Emarsys.Sdk.Responses
{
    internal class TokenResponse
    {
        [JsonPropertyName("access_token")]
        public string Token { get; set; }
    
        [JsonPropertyName("expires_in")]
        public int Expiracao { get; set; }
    }
}
