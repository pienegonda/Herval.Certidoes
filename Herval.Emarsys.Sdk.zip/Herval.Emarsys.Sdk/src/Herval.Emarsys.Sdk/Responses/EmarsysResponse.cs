using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Herval.Emarsys.Sdk.Responses
{
    public class EmarsysResponse
    {
        [JsonPropertyName("replyCode")]
        public int CodigoResposta { get; set; }
    
        [JsonPropertyName("replyText")]
        public string MensagemResposta { get; set; }
    
        [JsonPropertyName("data")]
        public EmarsysResponseData Data { get; set; }
    }
    
    public class EmarsysResponseData
    {
        [JsonPropertyName("ids")]
        public List<string> Ids { get; set; } = new List<string>();
    
        [JsonPropertyName("errors")]
        public Dictionary<string, Dictionary<string, string>> Errors { get; set; }
    }
}
