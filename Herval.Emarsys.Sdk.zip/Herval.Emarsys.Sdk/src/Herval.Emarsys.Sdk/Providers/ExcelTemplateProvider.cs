﻿using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Enums;
using Herval.Emarsys.Sdk.Interfaces;
using Herval.Emarsys.Sdk.Templates.Excel;

namespace Herval.Emarsys.Sdk.Providers
{
    public class ExcelTemplateProvider
    {
        public IExcelTemplate<T> ObterExcelTemplate<T>(ENegocio negocio) where T : VendaBaseDto
        {
            return negocio switch
            {
                ENegocio.IplaceUY => (IExcelTemplate<T>)new VendaIplaceUruguaiExcelTemplate(),
                ENegocio.HsFinanceira => (IExcelTemplate<T>)new VendaFinanceiraExcelTemplate(),
                ENegocio.HsConsorcio => (IExcelTemplate<T>)new VendaConsorcioExcelTemplate(),
                ENegocio.Corretora => (IExcelTemplate<T>)new VendaCorretoraExcelTemplate(),
                _ => (IExcelTemplate<T>)new VendaExcelTemplate(),
            };
        }
    }
}
