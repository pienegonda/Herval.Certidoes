﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace Herval.Emarsys.Sdk.Providers
{
    /// <summary>
    /// Provedor de configurações para serialização JSON.
    /// </summary>
    internal static class JsonSerializerOptionsProvider
    {
        /// <summary>
        /// Obtém as opções padrão de serialização JSON configuradas para a SDK.
        /// </summary>
        public static JsonSerializerOptions DefaultOptions => new()
        {
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        };
    }
}
