﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Herval.Emarsys.Sdk.Enums;
using Herval.Emarsys.Sdk.Models;

namespace Herval.Emarsys.Sdk.Providers
{
    public class EmarsysCredencialProvider
    {
        private readonly Dictionary<string, Credencial> _credenciais;
    
        public EmarsysCredencialProvider()
        {
            var assemblyLocation = typeof(EmarsysCredencialProvider).Assembly.Location;
            var assemblyDirectory = Path.GetDirectoryName(assemblyLocation);
            var credenciaisPath = Path.Combine(assemblyDirectory, "Sources", "credenciais.json");
    
            if (!File.Exists(credenciaisPath))
            {
                throw new FileNotFoundException($"O arquivo de credenciais não foi encontrado no caminho: {credenciaisPath}");
            }
    
            var json = File.ReadAllText(credenciaisPath);
            _credenciais = JsonSerializer.Deserialize<Dictionary<string, Credencial>>(json);
        }
    
        public Credencial ObterCredencial(ENegocio negocio) =>
            negocio switch
            {
                ENegocio.Taqi => _credenciais["Taqi"],
                ENegocio.Iplace => _credenciais["Iplace"],
                ENegocio.VouLevar => _credenciais["VouLevar"],
                ENegocio.HsFinanceira => _credenciais["HsFinanceira"],
                ENegocio.HsConsorcio => _credenciais["HsConsorcio"],
                ENegocio.TaqiCorp => _credenciais["TaqiCorp"],
                ENegocio.IplaceCorp => _credenciais["IplaceCorp"],
                ENegocio.IplaceUY => _credenciais["IplaceUY"],
                ENegocio.HTSolutions => _credenciais["HTSolutions"],
                ENegocio.Herval => _credenciais["Herval"],
                ENegocio.MisterTech => _credenciais["MisterTech"],
                ENegocio.UUltis => _credenciais["UUltis"],
                ENegocio.Volis => _credenciais["Volis"],
                ENegocio.Corretora => _credenciais["Corretora"],
                _ => throw new ArgumentOutOfRangeException(nameof(negocio), $"Negócio {negocio} não mapeado.")
            };
    }
}
