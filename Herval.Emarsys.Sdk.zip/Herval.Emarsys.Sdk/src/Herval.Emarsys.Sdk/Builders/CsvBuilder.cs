﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Herval.Emarsys.Sdk.Builders
{
    public class CsvBuilder<T>
    {
        private string[] _headers;

        private string[] _subHeaders;

        private Func<T, object>[] _mappers;

        private IEnumerable<T> _data;

        private string _worksheetName;

        private int[] _blankSpace;


        public CsvBuilder<T> WithWorksheetName(string name)
        {
            _worksheetName = name;
            return this;
        }

        public CsvBuilder<T> WithBlankSpaces(params int[] blankSpace)
        {
            _blankSpace = blankSpace;
            return this;
        }

        public CsvBuilder<T> WithSubHeaders(params string[] subHeaders)
        {
            _subHeaders = subHeaders;
            return this;
        }

        public CsvBuilder<T> WithHeaders(params string[] headers)
        {
            _headers = headers;
            return this;
        }

        public CsvBuilder<T> WithMappers(params Func<T, object>[] mappers)
        {
            _mappers = mappers;
            return this;
        }

        public CsvBuilder<T> WithData(params T[] data)
        {
            _data = data;
            return this;
        }

        public CsvBuilder<T> WithData(IEnumerable<T> data)
        {
            _data = data;
            return this;
        }

        public byte[] BuildToStream()
        {
            using var memoryStream = new MemoryStream();
            using var streamWriter = new StreamWriter(memoryStream, System.Text.Encoding.UTF8, 1024, true);

            if (_headers != null && _headers.Length > 0)
                streamWriter.WriteLine(string.Join(",", _headers));


            if (_subHeaders != null && _subHeaders.Length > 0)
                streamWriter.WriteLine(string.Join(",", _subHeaders));


            if (_data != null && _mappers != null)
            {
                foreach (var item in _data)
                {
                    var values = new List<string>();

                    foreach (var mapper in _mappers)
                    {
                        var value = mapper(item);
                        values.Add(value?.ToString() ?? "");
                    }

                    streamWriter.WriteLine(string.Join(",", values));
                }
            }

            streamWriter.Flush();
            
            return memoryStream.ToArray();
        }
    }
}