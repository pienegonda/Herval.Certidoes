﻿using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;

namespace Herval.Emarsys.Sdk.Utils
{
    /// <summary>
    /// Utilitário para converter arquivos locais para o formato CSV da Emarsys
    /// </summary>
    public class EmarsysFileConverter
    {
        private readonly IFileExporter<ProdutoDto> _produtoExporter;
        private readonly IFileExporter<VendaDto> _vendaExporter;

        /// <summary>
        /// Construtor
        /// </summary>
        public EmarsysFileConverter(
            IFileExporter<ProdutoDto> produtoExporter,
            IFileExporter<VendaDto> vendaExporter)
        {
            _produtoExporter = produtoExporter;
            _vendaExporter = vendaExporter;
        }

        /// <summary>
        /// Converte um arquivo de produtos para o formato Emarsys e salva em disco
        /// </summary>
        /// <param name="caminhoArquivoEntrada">Caminho do arquivo de entrada</param>
        /// <param name="caminhoArquivoSaida">Caminho onde o arquivo será salvo</param>
        /// <returns>Caminho do arquivo gerado</returns>
        public string ConverterArquivoProdutos(string caminhoArquivoEntrada, string caminhoArquivoSaida)
        {
            // Ler o arquivo de entrada e converter para lista de ProdutoDto
            var produtos = LerArquivoProdutos(caminhoArquivoEntrada);

            // Usar o exporter para gerar o CSV no formato Emarsys
            var csvBytes = _produtoExporter.GerarArquivoCSVEmBytes(produtos);

            // Salvar o resultado em disco
            File.WriteAllBytes(caminhoArquivoSaida, csvBytes);

            return caminhoArquivoSaida;
        }

        /// <summary>
        /// Converte um arquivo de vendas para o formato Emarsys e salva em disco
        /// </summary>
        /// <param name="caminhoArquivoEntrada">Caminho do arquivo de entrada</param>
        /// <param name="caminhoArquivoSaida">Caminho onde o arquivo será salvo</param>
        /// <returns>Caminho do arquivo gerado</returns>
        public string ConverterArquivoVendas(string caminhoArquivoEntrada, string caminhoArquivoSaida)
        {
            // Ler o arquivo de entrada e converter para lista de VendaDto
            var vendas = LerArquivoVendas(caminhoArquivoEntrada);

            // Usar o exporter para gerar o CSV no formato Emarsys
            var csvBytes = _vendaExporter.GerarArquivoCSVEmBytes(vendas);

            // Salvar o resultado em disco
            File.WriteAllBytes(caminhoArquivoSaida, csvBytes);

            return caminhoArquivoSaida;
        }

        /// <summary>
        /// Lê um arquivo CSV e converte para uma lista de ProdutoDto
        /// </summary>
        private List<ProdutoDto> LerArquivoProdutos(string caminhoArquivo)
        {
            var produtos = new List<ProdutoDto>();
            var linhas = File.ReadAllLines(caminhoArquivo);

            // Pular o cabeçalho (primeira linha)
            for (int i = 1; i < linhas.Length; i++)
            {
                var campos = linhas[i].Split(';'); // Ajuste o separador conforme seu arquivo

                if (campos.Length >= 9)
                {
                    produtos.Add(new ProdutoDto(
                        item: campos[0].Trim(),
                        nome: campos[1].Trim(),
                        link: campos[2].Trim(),
                        imagemLink: campos[3].Trim(),
                        preco: decimal.Parse(campos[4].Trim()),
                        categoria: campos[5].Trim(),
                        disponivel: bool.Parse(campos[6].Trim().ToLower()),
                        marca: campos[7].Trim(),
                        descricao: campos[8].Trim()
                    ));
                }
            }

            return produtos;
        }

        /// <summary>
        /// Lê um arquivo CSV e converte para uma lista de VendaDto
        /// </summary>
        private List<VendaDto> LerArquivoVendas(string caminhoArquivo)
        {
            var vendas = new List<VendaDto>();
            var linhas = File.ReadAllLines(caminhoArquivo);

            // Pular o cabeçalho (primeira linha)
            for (int i = 1; i < linhas.Length; i++)
            {
                var campos = linhas[i].Split(';'); // Ajuste o separador conforme seu arquivo

                if (campos.Length >= 8)
                {
                    // Ajuste os índices conforme as colunas do seu arquivo
                    vendas.Add(new VendaDto(
                        origem: campos[3].Trim(),
                        orderId: campos[7].Trim(),
                        dataVenda: DateTime.Parse(campos[8].Trim()),
                        moeda: campos[9].Trim(),
                        cliente: campos[12].Trim(),
                        documento: campos[12].Trim(),
                        item: campos[13].Trim(),
                        precoOriginal: decimal.Parse(campos[14].Trim()),
                        preco: decimal.Parse(campos[15].Trim()),
                        quantidade: decimal.Parse(campos[16].Trim()),
                        cupom: campos[0].Trim(),
                        categoriaPromocao: campos[17].Trim(),
                        matriculaVendedor: string.Empty,
                        nomeVendedor: campos[10].Trim(),
                        nomeLoja: campos[4].Trim(),
                        cidadeLoja: campos[5].Trim(),
                        estadoLoja: campos[6].Trim(),
                        numeroNotaFiscal: campos[11].Trim(),
                        tipoPagamento: campos[18].Trim(),
                        pedidoEcommerceId: campos[19].Trim(),
                        multimeios: string.Empty
                    ));
                }
            }

            return vendas;
        }
    }
}