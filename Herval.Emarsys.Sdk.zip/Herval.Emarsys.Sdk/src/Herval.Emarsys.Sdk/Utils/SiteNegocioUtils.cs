﻿using System.Collections.Generic;
using Herval.Emarsys.Sdk.Enums;

namespace Herval.Emarsys.Sdk.Utils
{
    /// <summary>
    /// Utilitário para mapear siteId para ENegocio.
    /// </summary>
    public static class SiteNegocioUtils
    {
        private static readonly IReadOnlyDictionary<string, ENegocio> _siteIdToNegocio = new Dictionary<string, ENegocio>
        {
            { "iPlaceSite", ENegocio.Iplace },
            { "iPlaceSAM", ENegocio.Iplace },
            { "voulevar", ENegocio.VouLevar },
            { "basicSite", ENegocio.Taqi },
            { "taQiSAM", ENegocio.Taqi },
            { "Volis", ENegocio.Volis },
            { "Mistertech", ENegocio.MisterTech },
            { "MistertechSAM", ENegocio.MisterTech },
            { "iPlaceUY", ENegocio.IplaceUY },
            { "iPlaceB2B", ENegocio.IplaceCorp },
            { "taQiB2B", ENegocio.TaqiCorp },
            { "soleSAM", ENegocio.UUltis }
        };

        /// <summary>
        /// Obtém o ENegocio correspondente ao siteId informado.
        /// </summary>
        /// <param name="siteId">Identificador do site.</param>
        /// <returns>ENegocio correspondente ou null se não encontrado.</returns>
        public static ENegocio? ObterNegocioPorSiteId(string siteId)
        {
            if (_siteIdToNegocio.TryGetValue(siteId, out var negocio))
                return negocio;
            return null;
        }
    }
}