﻿using Herval.Emarsys.Sdk.Enums;
using Herval.Emarsys.Sdk.Extensions;
using Herval.Emarsys.Sdk.Providers;
using Herval.Emarsys.Sdk.Responses;
using Herval.Http.Extensions;
using Herval.Notifications.Interfaces;
using IdentityModel.Client;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Herval.Emarsys.Sdk.Services
{
    public abstract class EmarsysBaseService
    {
        protected readonly HttpClient _httpClient;
        protected readonly INotificationContext _notificationContext;
        protected readonly EmarsysCredencialProvider _emarsysCredencialProvider;
        private DateTime _dataExpiracaoToken;
        private ENegocio _negocioAutenticado;

        public EmarsysBaseService(
            HttpClient httpClient,
            INotificationContext notificationContext,
            EmarsysCredencialProvider emarsysCredencialProvider)
        {
            _httpClient = httpClient;
            _notificationContext = notificationContext;
            _emarsysCredencialProvider = emarsysCredencialProvider;
        }

        protected async Task AutenticarAsync(ENegocio negocio, CancellationToken cancellationToken)
        {
            if (_negocioAutenticado == negocio && _dataExpiracaoToken >= DateTime.Now)
                return;

            var credencial = _emarsysCredencialProvider.ObterCredencial(negocio);

            var base64Credencial = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{credencial.ClientId}:{credencial.ClientSecret}"));

            var content = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                { "grant_type", "client_credentials" }
            });

            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64Credencial);

            var response = await _httpClient.PostAsync("https://auth.emarsys.net/oauth2/token", content, cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                _notificationContext.AddNotification("Erro ao autenticar com a api Emarsys");
                return;
            }

            var tokenReponse = await response.Content.ReadFromJsonAsync<Responses.TokenResponse>();

            _dataExpiracaoToken = DateTime.Now.AddSeconds(tokenReponse.Expiracao);
            _negocioAutenticado = negocio;
            _httpClient.SetBearerToken(tokenReponse?.Token);
        }

        protected async Task TratamentoRetorno(HttpResponseMessage response)
        {
            switch (response.StatusCode)
            {
                case HttpStatusCode.OK:
                    // Gambiarra pois a emarsys retorna 200 mesmo com erros
                    await TratamentoErrosAsync(response);
                    break;

                case HttpStatusCode.NoContent:
                    break;

                case HttpStatusCode.UnprocessableEntity:
                    _notificationContext.AddNotifications(await response.ReadHervalBadRequestNotificationsAsync());
                    break;

                case HttpStatusCode.ServiceUnavailable:
                    _notificationContext.AddNotification("Serviço da Emarsys está temporariamente indisponível");
                    break;
                case HttpStatusCode.BadRequest:
                    await TratamentoErrosAsync(response);
                    break;

                default:
                    _notificationContext.AddNotification($"Houve um erro desconhecido ao processar sua requisição - {response}");
                    break;
            }
        }

        private async Task TratamentoErrosAsync(HttpResponseMessage response)
        {
            var mensagemErro = response.Content.ReadAsStringAsync().Result;
            if (!mensagemErro.Contains("errors") || mensagemErro.Contains("\"errors\":[]"))
                return;

            var emarsysResponse = await response.Content.ReadFromJsonAsync<EmarsysResponse>();

            if (emarsysResponse.TemErros())
            {
                foreach (var mensagem in emarsysResponse.ObterMensagensErro())
                {
                    _notificationContext.AddNotification(mensagem);
                }
            }
        }
    }
}
