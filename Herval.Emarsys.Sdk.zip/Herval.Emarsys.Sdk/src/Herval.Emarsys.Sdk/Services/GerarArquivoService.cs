using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;
using Herval.Emarsys.Sdk.Providers;
using Herval.Notifications.Interfaces;

namespace Herval.Emarsys.Sdk.Services
{
    public class GerarArquivoService : IGerarArquivoService
    {
        private readonly INotificationContext _notificationContext;
        private readonly IExcelService _excelService;
        private readonly ExcelTemplateProvider _obterExcelTemplateProvider;

        public GerarArquivoService(
            INotificationContext notificationContext,
            IExcelService excelService,
            ExcelTemplateProvider obterExcelTemplateProvider)
        {
            _notificationContext = notificationContext;
            _excelService = excelService;
            _obterExcelTemplateProvider = obterExcelTemplateProvider;
        }

        public byte[] GerarArquivoCsv<T>(EnviarVendaDto<T> venda) where T : VendaBaseDto
        {
            var template = _obterExcelTemplateProvider.ObterExcelTemplate<T>(venda.Negocio) ;

            return _excelService.ExportarParaCsv<T>(
                template.WorksheetName,
                venda.Vendas,
                template.SubHeaders,
                template.Mappers
            );
        }
    }
}
