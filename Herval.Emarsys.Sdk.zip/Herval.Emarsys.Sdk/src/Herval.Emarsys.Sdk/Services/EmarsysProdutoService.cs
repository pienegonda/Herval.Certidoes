using System;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;
using Herval.Emarsys.Sdk.Providers;
using Herval.Notifications.Interfaces;
using Renci.SshNet;

namespace Herval.Emarsys.Sdk.Services
{
    public class EmarsysProdutoService : EmarsysBaseService, IEmarsysProdutoService
    {
        private const string FTP_EMARSYS = "exchange.si.emarsys.net";
        private const int FTP_PORTA_EMARSYS = 22;
        
        private readonly IFileExporter<ProdutoDto> _csvProdutoExporter;
    
        public EmarsysProdutoService(
            HttpClient httpClient,
            INotificationContext notificationContext,
            EmarsysCredencialProvider emarsysCredencialProvider,
            IFileExporter<ProdutoDto> csvProdutoExporter)
            : base(httpClient, notificationContext, emarsysCredencialProvider)
        {
            _csvProdutoExporter = csvProdutoExporter;
        }

        public async Task EnviarProdutoAsync(EnviarProdutoDto enviarProdutoDto, CancellationToken cancellationToken)
        {
            try
            {
                var credencial = _emarsysCredencialProvider.ObterCredencial(enviarProdutoDto.Negocio);

                var csvEmBytes = _csvProdutoExporter.GerarArquivoCSVEmBytes(enviarProdutoDto.Produtos);

                if (csvEmBytes == null || csvEmBytes.Length == 0)
                {
                    _notificationContext.AddNotification("Erro ao gerar arquivo CSV. Verifique os dados dos produtos.");
                    return;
                }

                using (var sftp = new SftpClient(FTP_EMARSYS, FTP_PORTA_EMARSYS, credencial.UsuarioFTP, credencial.SenhaFTP))
                {
                    await sftp.ConnectAsync(cancellationToken);

                    using (var fileStream = new MemoryStream(csvEmBytes))
                    {
                        sftp.UploadFile(fileStream, $"products_{credencial.BU}.csv");
                    }

                    sftp.Disconnect();
                }
            }
            catch (Exception ex)
            {
                _notificationContext.AddNotification("Erro ao conectar/enviar arquivo: " + ex.Message);
            }
        }
    }
}
