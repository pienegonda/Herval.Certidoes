﻿using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Extensions;
using Herval.Emarsys.Sdk.Interfaces;
using Herval.Emarsys.Sdk.Mappers;
using Herval.Emarsys.Sdk.Providers;
using Herval.Extensions.ICollections;
using Herval.Notifications.Interfaces;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Herval.Emarsys.Sdk.Services
{
    public class EmarsysEventoService : EmarsysBaseService, IEmarsysEventoService
    {
        public EmarsysEventoService(
            HttpClient httpClient,
            INotificationContext notificationContext,
            EmarsysCredencialProvider emarsysCredencialProvider)
            : base(httpClient, notificationContext, emarsysCredencialProvider)
        {
        }
        
        /// <summary>
        /// É possivel enviar eventos para múltiplos contatos, disparar um e-mail para vários destinatários separando por vírgula.
        /// Exemplo: teste@herval.com.br, teste2@herval.com.br
        /// </summary>
        public async Task EnviarEventoAsync(EnviarEventoDto enviarEventoDto, CancellationToken cancellationToken)
        {
            try
            {
                if (AnexosComProblemas(enviarEventoDto.Anexos))
                    return;

                await AutenticarAsync(enviarEventoDto.Negocio, cancellationToken);

                var request = EnviarEventoEmarsysRequestMapper.Map(enviarEventoDto);

                var response = await _httpClient.PostAsJsonAsync(
                    $"api/v3/event/{enviarEventoDto.EventoId}/trigger",
                    request,
                    JsonSerializerOptionsProvider.DefaultOptions,
                    cancellationToken);

                await TratamentoRetorno(response);
            }
            catch (Exception ex)
            {
                _notificationContext.AddNotification("Erro ao criar evento na emarsys: " + ex.Message);
            }
        }

        private bool AnexosComProblemas(List<AnexoEmailDto> anexos)
        {
            if (anexos.IsNullOrEmpty())
                return false;

            var anexosComTamanhoMaxExcedido = new List<AnexoEmailDto>();
            var tamanhoMaximoBytes = 10 * 1024 * 1024; //10MB

            if (anexos.Count > 10)
            {
                _notificationContext.AddNotification("Quantidade de anexos superior a 10 anexos");
                return true;
            }

            foreach (var anexo in anexos)
            {
                var arquivoBase64 = anexo.ArquivoBase64;

                var arquivoBytes = Convert.FromBase64String(arquivoBase64.RemoveHeaderBase64());

                if (arquivoBytes.Length > tamanhoMaximoBytes)
                {
                    _notificationContext.AddNotification($"O arquivo {anexo.NomeArquivo} n�o pode ser maior que 10MB");
                    anexosComTamanhoMaxExcedido.Add(anexo);
                }
            }

            if (anexosComTamanhoMaxExcedido.Count > 0)
                return true;

            return false;
        }
    }
}
