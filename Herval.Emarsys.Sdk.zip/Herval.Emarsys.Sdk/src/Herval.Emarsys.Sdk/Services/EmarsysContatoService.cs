using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Enums;
using Herval.Emarsys.Sdk.Interfaces;
using Herval.Emarsys.Sdk.Mappers;
using Herval.Emarsys.Sdk.Providers;
using Herval.Notifications.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Herval.Emarsys.Sdk.Services
{
    public class EmarsysContatoService : EmarsysBaseService, IEmarsysContatoService
    {
        public EmarsysContatoService(
            HttpClient httpClient,
            INotificationContext notificationContext,
            EmarsysCredencialProvider emarsysCredencialProvider)
            : base(httpClient, notificationContext, emarsysCredencialProvider)
        {
        }

        public async Task CriarContatoAsync<T>(EnviarContatoDto<T> criarContatoDto, CancellationToken cancellationToken) where T : ContatoBaseDto
        {
            try
            {
                await AutenticarAsync(criarContatoDto.Negocio, cancellationToken);
            
                await EnviarContatosAsync(criarContatoDto.Negocio, criarContatoDto.Contatos, cancellationToken);

            }
            catch (Exception ex)
            {
                _notificationContext.AddNotification("Erro ao criar contato na emarsys: " + ex.Message);
            }
        }

        public async Task CriarFormsAsync(CriarFormsDto criarFormsDto, CancellationToken cancellationToken)
        {
            try
            {
                await AutenticarAsync(criarFormsDto.Negocio, cancellationToken);

                var request = CriarFormsEmarsysRequestMapper.Map(criarFormsDto);
                var response = await _httpClient.PostAsJsonAsync($"api/v3/form/{criarFormsDto.FormsId}/trigger", request, cancellationToken);

                await TratamentoRetorno(response);
            }
            catch (Exception ex)
            {
                _notificationContext.AddNotification("Erro ao criar forms na emarsys: " + ex.Message);
            }
        }

        public async Task AtualizarContatoAsync(AtualizarContatoDto atualizarContatoDto, CancellationToken cancellationToken)
        {
            try
            {
                await AutenticarAsync(atualizarContatoDto.Negocio, cancellationToken);

                var request = AtualizarContatoEmarsysRequestMapper.Map(atualizarContatoDto);

                var response = await _httpClient.PutAsJsonAsync("api/v3/contact/?create_if_not_exists=1", request, cancellationToken);

                await TratamentoRetorno(response);
            }
            catch (Exception ex)
            {
                _notificationContext.AddNotification("Erro ao atualizar contato na emarsys: " + ex.Message);
            }
        }

        private async Task EnviarContatosAsync(
            ENegocio negocio, 
            IEnumerable<ContatoBaseDto> contatos, 
            CancellationToken cancellationToken)
        {
            var request = CriarContatoRequestMapper.Map(negocio, contatos);
            var response = await _httpClient.PutAsJsonAsync("api/v3/contact/?create_if_not_exists=1", request, cancellationToken);
            await TratamentoRetorno(response);
        }
    }
}
