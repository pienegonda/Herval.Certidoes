﻿using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;
using Herval.Emarsys.Sdk.Providers;
using Herval.Notifications.Interfaces;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;

namespace Herval.Emarsys.Sdk.Services
{
    public class EmarsysVendaService : EmarsysBaseService, IEmarsysVendaService
    {
        private readonly IGerarArquivoService _gerarArquivoService;

        public EmarsysVendaService(
            HttpClient httpClient,
            INotificationContext notificationContext,
            EmarsysCredencialProvider emarsysCredencialProvider,
            IGerarArquivoService gerarArquivoService)
            : base(httpClient, notificationContext, emarsysCredencialProvider)
        {
            _gerarArquivoService = gerarArquivoService;
        }

        public async Task EnviarVendaAsync<T>(EnviarVendaDto<T> enviarVendaDto, CancellationToken cancellationToken) where T : VendaBaseDto
        {
            try
            {
                var credencial = _emarsysCredencialProvider.ObterCredencial(enviarVendaDto.Negocio);

                var csvEmBytes = _gerarArquivoService.GerarArquivoCsv(enviarVendaDto);

                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", credencial.TokenVenda);

                var content = new ByteArrayContent(csvEmBytes);
                content.Headers.ContentType = new MediaTypeHeaderValue("text/csv");

                var response = await _httpClient.PostAsync($"hapi/merchant/{credencial.MerchantId}/sales-data/api", content, cancellationToken);

                await TratamentoRetorno(response);
            }
            catch (Exception ex)
            {
                _notificationContext.AddNotification("Erro ao enviar arquivo de vendas: " + ex.Message);
            }
        }
    }
}
