using System;
using System.Collections.Generic;
using System.Linq;
using Herval.Emarsys.Sdk.Builders;
using Herval.Emarsys.Sdk.Interfaces;

namespace Herval.Emarsys.Sdk.Services
{
    public class ExcelService : IExcelService
    {
        public byte[] ExportarParaCsv<T>(
            string worksheetName,
            IEnumerable<T> data,
            IEnumerable<string> subHeaders,
            IEnumerable<Func<T, string>> mappers)
        {
            return BuildCsv(
                worksheetName,
                data,
                subHeaders,
                mappers);
        }

        private static byte[] BuildCsv<T>(
            string worksheetName,
            IEnumerable<T> data,
            IEnumerable<string> subHeaders,
            IEnumerable<Func<T, string>> mappers)
        {
            var csvBuilder = new CsvBuilder<T>()
                .WithWorksheetName(worksheetName)
                .WithSubHeaders(subHeaders.ToArray());

            if (mappers is not null)
                csvBuilder.WithMappers(mappers.ToArray());

            if (data is not null)
                csvBuilder.WithData(data);

            return csvBuilder.BuildToStream();
        }
    }
}