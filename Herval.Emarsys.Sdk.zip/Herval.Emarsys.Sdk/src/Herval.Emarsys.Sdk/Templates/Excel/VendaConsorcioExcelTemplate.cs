using System;
using System.Globalization;
using System.Linq;
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;

namespace Herval.Emarsys.Sdk.Templates.Excel
{
    public class VendaConsorcioExcelTemplate : IExcelTemplate<ConsorcioDto>
    {
        private readonly (string SubHeader, Func<ConsorcioDto, string> Mapper)[] _mapeamentos =
        {
            (SubHeaderNames.Item, p => p?.Bem),
            (SubHeaderNames.Price, p => p?.ValorParcela.ToString("0.00", CultureInfo.InvariantCulture)),
            (SubHeaderNames.Order, p => p.CotaId),
            (SubHeaderNames.Timestamp, p => p.DataVenda.ToString("yyyy-MM-ddTHH:mm:ss") + "Z"),
            (SubHeaderNames.Customer, p => p.Documento.ToString()),
            (SubHeaderNames.Quantity, p => p.QuantidadeParcelas.ToString()),
            (SubHeaderNames.Type, p => p.Tipo),
            (SubHeaderNames.Group, p => p.CodigoGrupo),
            (SubHeaderNames.CodCota, p => p.CodigoCota),
            (SubHeaderNames.Versao, p => p.Versao),
            (SubHeaderNames.Corretora, p => p.CorretoraId),
            (SubHeaderNames.NomeCorretora, p => p.NomeCorretora),
            (SubHeaderNames.CidadeCorretora, p => p.CidadeCorretora),
            (SubHeaderNames.EstadoCorretora, p => p.EstadoCorretora),
            (SubHeaderNames.CodVendedor, p => p.VendedorId ??""),
            (SubHeaderNames.NomeVendedor, p => p.NomeVendedor),
            (SubHeaderNames.ValorParcela, p => p.ValorParcela.ToString("0.00", CultureInfo.InvariantCulture) ?? "0.00"),
            (SubHeaderNames.QtdParcelas, p => p.QuantidadeParcelas.ToString() ?? "0"),
            (SubHeaderNames.DataEncerramento, p => p.DataEncerramento.ToString("yyyy-MM-ddTHH:mm:ss") + "Z"),
        };

        public string WorksheetName => WorksheetNames.Vendas;

        public string[] SubHeaders => _mapeamentos.Select(m => m.SubHeader).ToArray();

        public Func<ConsorcioDto, string>[] Mappers => _mapeamentos.Select(m => m.Mapper).ToArray();

        public static class SubHeaderNames
        {
            public const string Item = "item,";
            public const string Price = "price,";
            public const string Order = "order,";
            public const string Timestamp = "timestamp,";
            public const string Customer = "customer,";
            public const string Quantity = "quantity,";
            public const string Type = "s_type,";
            public const string Group = "i_group,";
            public const string CodCota = "i_cod_cota,";
            public const string Versao = "i_versao,";
            public const string Corretora = "i_corretora,";
            public const string NomeCorretora = "s_nome_corretora,";
            public const string CidadeCorretora = "s_cidade_corretora,";
            public const string EstadoCorretora = "s_estado_corretora,";
            public const string CodVendedor = "i_cod_vendedor,";
            public const string NomeVendedor = "s_nome_vendedor,";
            public const string ValorParcela = "f_valor_parcela,";
            public const string QtdParcelas = "i_qtd_parcelas,";
            public const string DataEncerramento = "t_data_encerramento";
        }

        public static class WorksheetNames
        {
            public const string Vendas = "Consorcios";
        }
    }
}
