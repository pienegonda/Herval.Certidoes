using System;
using System.Globalization;
using System.Linq;
using Herval.Emarsys.Sdk.Dtos;

namespace Herval.Emarsys.Sdk.Templates.Excel
{
    public class VendaCorretoraExcelTemplate
    {
        private readonly (string SubHeader, Func<VendaCorretoraDto, string> Mapper)[] _mapeamentos =
        {
            (SubHeaderNames.Documento, p => p.Documento),
            (SubHeaderNames.Filial, p => p.Filial.ToString()),
            (SubHeaderNames.Item, p => p.Ramo.ToString()),
            (SubHeaderNames.InicioVigencia, p => p.InicioVigencia.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)),
            (SubHeaderNames.FimVigencia, p => p.FimVigencia.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)),
            (SubHeaderNames.NumeroProposta, p => p.NumeroProposta),
            (SubHeaderNames.Quantity, p => p.Quantidade.ToString()),
            (SubHeaderNames.TipoNegociacao, p => p.TipoNegociacao),
            (SubHeaderNames.Ramo, p => p.Ramo),
            (SubHeaderNames.Valor, p => p.Valor.ToString("F2", CultureInfo.InvariantCulture)),
            (SubHeaderNames.Comissao, p => p.Comissao.ToString("F2", CultureInfo.InvariantCulture)),
            (SubHeaderNames.Parcelas, p => p.Parcelas.ToString()),
            (SubHeaderNames.Renovacao, p => p.Renovacao.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)),
            (SubHeaderNames.DescricaoItem, p => p.DescricaoItem),
            (SubHeaderNames.RamoTipo, p => p.RamoTipo),
            (SubHeaderNames.Seguradora, p => p.Seguradora),
            (SubHeaderNames.FormaPagamento, p => p.FormaPagamento)
        };

        public string WorksheetName => WorksheetNames.Vendas;

        public string[] SubHeaders => _mapeamentos.Select(m => m.SubHeader).ToArray();

        public Func<VendaCorretoraDto, string>[] Mappers => _mapeamentos.Select(m => m.Mapper).ToArray();

        public static class SubHeaderNames
        {
            public const string Documento = "customer";
            public const string Filial = "i_s_store";
            public const string Item = "item";
            public const string InicioVigencia = "timestamp";
            public const string FimVigencia = "fim_vigencia";
            public const string NumeroProposta = "order";
            public const string Quantity = "quantity";
            public const string TipoNegociacao = "s_tipo_negociacao";
            public const string Ramo = "s_ramo";
            public const string Valor = "price";
            public const string Comissao = "valor_comissao";
            public const string Parcelas = "i_parcelas";
            public const string Renovacao = "data_renovacao";
            public const string DescricaoItem = "s_descricao_item";
            public const string RamoTipo = "s_ramo_tipo";
            public const string Seguradora = "s_seguradora";
            public const string FormaPagamento = "s_forma_pag";
        }

        public static class WorksheetNames
        {
            public const string Vendas = "VendasCorretora";
        }
    }
}