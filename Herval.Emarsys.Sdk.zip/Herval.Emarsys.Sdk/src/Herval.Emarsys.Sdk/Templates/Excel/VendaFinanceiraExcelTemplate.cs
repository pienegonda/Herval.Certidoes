using System;
using System.Globalization;
using System.Linq;
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;
using Herval.Extensions.StringExtensions;

namespace Herval.Emarsys.Sdk.Templates.Excel
{
    public class VendaFinanceiraExcelTemplate : IExcelTemplate<FinanceiraDto>
    {
        private readonly (string SubHeader, Func<FinanceiraDto, string> Mapper)[] _mapeamentos =
        {
            (SubHeaderNames.Item, p => p?.DescricaoProduto),
            (SubHeaderNames.Price, p => (p.PrecoTotal ?? 0).ToString("0.00", CultureInfo.InvariantCulture)),
            (SubHeaderNames.Order, p => p.IdentificadorInterno),
            (SubHeaderNames.Timestamp, p => p.DataTransacao.ToString("yyyy-MM-ddTHH:mm:ssZ", CultureInfo.InvariantCulture)),
            (SubHeaderNames.Customer, p => p.Cliente),
            (SubHeaderNames.Quantity, p => (p.QuantidadeItemFinanceiro ?? 1).ToString(CultureInfo.InvariantCulture)),
            (SubHeaderNames.Market, p => ""),
            (SubHeaderNames.OriginalPrice, p => (p.ValorOriginal ?? 0).ToString("0.00", CultureInfo.InvariantCulture)),
            (SubHeaderNames.OriginalCurrency, p => p.Moeda ?? "BRL"),
            (SubHeaderNames.Store, p => p.IdentificadorLoja?.ToOnlyNumbers()),
            (SubHeaderNames.CityStore, p => p.CidadeVenda),
            (SubHeaderNames.StateStore, p => p.UfLoja),
            (SubHeaderNames.QtdParcelas, p => (p.QuantidadeParcelas ?? 1).ToString(CultureInfo.InvariantCulture)),
            (SubHeaderNames.SellerId, p => ""),
            (SubHeaderNames.Name, p => ""),
            (SubHeaderNames.PedidoEcom, p => ""),
            (SubHeaderNames.NomeVendedor, p => ""),
            (SubHeaderNames.MatriculaVendedor, p => ""),
            (SubHeaderNames.NumeroContrato, p => "")
        };

        public string WorksheetName => WorksheetNames.Vendas;

        public string[] SubHeaders => _mapeamentos.Select(m => m.SubHeader).ToArray();

        public Func<FinanceiraDto, string>[] Mappers => _mapeamentos.Select(m => m.Mapper).ToArray();

        public static class SubHeaderNames
        {
            public const string Item = "item";
            public const string Price = "price";
            public const string Order = "order";
            public const string Timestamp = "timestamp";
            public const string Customer = "customer";
            public const string Quantity = "quantity";
            public const string Market = "s_market";
            public const string OriginalPrice = "f_originalPrice";
            public const string OriginalCurrency = "s_originalCurrency";
            public const string Store = "i_s_store";
            public const string CityStore = "s_city_store";
            public const string StateStore = "s_state_store";
            public const string QtdParcelas = "i_qtd_parcelas";
            public const string SellerId = "s_seller_id";
            public const string Name = "s_string_name";
            public const string PedidoEcom = "s_pedido_ecom";
            public const string NomeVendedor = "s_nome_vendedor";
            public const string MatriculaVendedor = "i_matricula_vendedor";
            public const string NumeroContrato = "s_numero_contrato";
        }

        public static class WorksheetNames
        {
            public const string Vendas = "Financeira";
        }
    }
}