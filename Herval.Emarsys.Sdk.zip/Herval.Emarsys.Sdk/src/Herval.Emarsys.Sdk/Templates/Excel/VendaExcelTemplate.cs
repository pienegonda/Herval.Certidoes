using System;
using System.Globalization;
using System.Linq;
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;

namespace Herval.Emarsys.Sdk.Templates.Excel
{
    public class VendaExcelTemplate : IExcelTemplate<VendaDto>
    {
        private readonly (string SubHeader, Func<VendaDto, string> Mapper)[] _mapeamentos =
        {
            (SubHeaderNames.Item, p => p?.Item),
            (SubHeaderNames.Price, p => p.Preco.ToString("0.00", CultureInfo.InvariantCulture) ?? "0.00"),
            (SubHeaderNames.Order, p => p.OrderId?.ToString()),
            (SubHeaderNames.Timestamp, p => p.DataVenda.ToString("yyyy-MM-ddTHH:mm:ssZ", CultureInfo.InvariantCulture)),
            (SubHeaderNames.Customer, p => p.Documento),
            (SubHeaderNames.Quantity, p => p.Quantidade.ToString("0.00", CultureInfo.InvariantCulture) ?? "1"),
            (SubHeaderNames.Market, p => p.Origem),
            (SubHeaderNames.OriginalPrice, p => p.PrecoOriginal.ToString("0.00", CultureInfo.InvariantCulture)),
            (SubHeaderNames.OriginalCurrency, p => p.Moeda ?? "BRL"),
            (SubHeaderNames.Color, p => ""),
            (SubHeaderNames.Size, p => ""),
            (SubHeaderNames.Store, p => p.NomeLoja),
            (SubHeaderNames.CityStore, p => p.CidadeLoja),
            (SubHeaderNames.StateStore, p => p.EstadoLoja),
            (SubHeaderNames.OrderDeliveryType, p => ""),
            (SubHeaderNames.Montagem, p => ""),
            (SubHeaderNames.MontagemDate, p => ""),
            (SubHeaderNames.OrderPaymentType, p => p.TipoPagamento),
            (SubHeaderNames.BinCartao, p => ""),
            (SubHeaderNames.QtdParcelas, p => ""),
            (SubHeaderNames.SellerId, p => p.MatriculaVendedor),
            (SubHeaderNames.SellerName, p => p.NomeVendedor),
            (SubHeaderNames.InvoiceNumber, p => p.NumeroNotaFiscal),
            (SubHeaderNames.Coupon, p => p.Cupom?.Replace(",", ".")),
            (SubHeaderNames.PedidoEcom, p => p.PedidoEcommerceId),
            (SubHeaderNames.PromotionCategory, p => p.CategoriaPromocao?.Replace(",", ".")),
            (SubHeaderNames.Multimeios, p => p.Multimeios)
        };

        public string WorksheetName => WorksheetNames.Vendas;

        public string[] SubHeaders => _mapeamentos.Select(m => m.SubHeader).ToArray();

        public Func<VendaDto, string>[] Mappers => _mapeamentos.Select(m => m.Mapper).ToArray();

        public static class SubHeaderNames
        {
            public const string Item = "item";
            public const string Price = "price";
            public const string Order = "order";
            public const string Timestamp = "timestamp";
            public const string Customer = "customer";
            public const string Quantity = "quantity";
            public const string Market = "s_market";
            public const string OriginalPrice = "f_originalPrice";
            public const string OriginalCurrency = "s_originalCurrency";
            public const string Color = "s_color";
            public const string Size = "f_size";
            public const string Store = "i_s_store";
            public const string CityStore = "s_city_store";
            public const string StateStore = "s_state_store";
            public const string OrderDeliveryType = "s_order_delivery_type";
            public const string Montagem = "s_montagem";
            public const string MontagemDate = "t_montagem_date";
            public const string OrderPaymentType = "s_order_payment_type";
            public const string BinCartao = "i_s_bin_cartao";
            public const string QtdParcelas = "i_qtd_parcelas";
            public const string SellerId = "s_seller_id";
            public const string SellerName = "s_string_name";
            public const string InvoiceNumber = "s_i_invoice_number";
            public const string Coupon = "s_coupon";
            public const string PedidoEcom = "s_pedido_ecom";
            public const string PromotionCategory = "s_promotion_category";
            public const string Multimeios = "s_multimeios";
        }

        public static class WorksheetNames
        {
            public const string Vendas = "Vendas";
        }
    }
}
