using System.Text.Json.Serialization;

namespace Herval.Emarsys.Sdk.Requests
{
    internal class AnexoEmailEmarsysRequest
    {
        [JsonPropertyName("filename")]
        public string NomeArquivo { get; set; }
    
        [JsonPropertyName("data")]
        public string ArquivoBase64 { get; set; }
    }
}
