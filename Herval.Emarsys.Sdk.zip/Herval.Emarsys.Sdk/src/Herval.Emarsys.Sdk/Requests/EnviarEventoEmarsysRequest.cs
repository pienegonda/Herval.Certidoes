using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Herval.Emarsys.Sdk.Requests
{
    internal class EnviarEventoEmarsysRequest
    {
        [JsonPropertyName("key_id")]
        public string ChaveEnvio { get; set; }
    
        [JsonPropertyName("external_id")]
        public string Identificacao { get; set; }
    
        [JsonPropertyName("data")]
        public Dictionary<string, string> Dados { get; set; }
    
        [JsonPropertyName("attachment")]
        public IEnumerable<AnexoEmailEmarsysRequest> Anexos { get; set; }
    }
}
