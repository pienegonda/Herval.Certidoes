using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Herval.Emarsys.Sdk.Requests
{
    internal class CriarContatoEmarsysRequest
    {
        [JsonPropertyName("key_id")]
        public string ChaveEnvio { get; set; }

        [JsonPropertyName("contacts")]
        public IList<Dictionary<string, string>> Dados { get; set; }
    }
}
