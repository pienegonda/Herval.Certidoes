using System.Text.Json.Serialization;

namespace Herval.Emarsys.Sdk.Requests
{
    internal class CriarFormsEmarsysRequest
    {
        [JsonPropertyName("key_id")]
        public string ChaveEnvio { get; set; }

        [JsonPropertyName("external_id")]
        public string Identificacao { get; set; }
    }
}
