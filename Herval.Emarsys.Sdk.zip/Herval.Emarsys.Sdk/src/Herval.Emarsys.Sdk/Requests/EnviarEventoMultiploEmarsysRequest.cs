using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Herval.Emarsys.Sdk.Requests
{
    internal class EnviarEventoMultiploEmarsysRequest
    {
        [JsonPropertyName("key_id")]
        public string ChaveEnvio { get; set; }
    
        [JsonPropertyName("contacts")]
        public IEnumerable<EnviarEventoEmarsysRequest> Contatos { get; set; }
    }
}
