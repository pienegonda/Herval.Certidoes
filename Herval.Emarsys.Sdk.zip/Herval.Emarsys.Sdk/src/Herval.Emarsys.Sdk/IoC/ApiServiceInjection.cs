﻿using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Exporters;
using Herval.Emarsys.Sdk.Interfaces;
using Herval.Emarsys.Sdk.Providers;
using Herval.Emarsys.Sdk.Services;
using Herval.Graylog.Middlewares;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace Herval.Emarsys.Sdk.IoC
{
    public static class ApiServiceInjection
    {
        public static IServiceCollection AddEmarsysEventoService(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<EmarsysCredencialProvider>();
            services.AddScoped<ExcelTemplateProvider>();

            services.AddHttpClient<IEmarsysEventoService, EmarsysEventoService>(client =>
            {
                var uri = configuration.GetValue<string>("ApiEmarsys:Endpoint");
                client.BaseAddress = new Uri(uri);
                client.DefaultRequestHeaders.Add("Accept", "application/json");
            })
            .AddHttpMessageHandler<HttpClientMessageHandler>();

            return services;
        }

        public static IServiceCollection AddEmarsysContatoService(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<EmarsysCredencialProvider>();
            services.AddScoped<ExcelTemplateProvider>();

            services.AddHttpClient<IEmarsysContatoService, EmarsysContatoService>(client =>
            {
                var uri = configuration.GetValue<string>("ApiEmarsys:Endpoint");
                client.BaseAddress = new Uri(uri);
                client.DefaultRequestHeaders.Add("Accept", "application/json");
            })
            .AddHttpMessageHandler<HttpClientMessageHandler>();

            return services;
        }

        public static IServiceCollection AddEmarsysVendaService<T>(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<EmarsysCredencialProvider>();
            services.AddScoped<IExcelService, ExcelService>();
            services.AddScoped<ExcelTemplateProvider>();
            services.AddScoped<IGerarArquivoService, GerarArquivoService>();

            services.AddHttpClient<IEmarsysVendaService, EmarsysVendaService>(client =>
            {
                var uri = configuration.GetValue<string>("ApiEmarsys:EndpointVendas");
                client.BaseAddress = new Uri(uri);
                client.DefaultRequestHeaders.Add("Accept", "text/plain");
                client.Timeout = TimeSpan.FromMinutes(5);
            })
            .AddHttpMessageHandler<HttpClientMessageHandler>();

            return services;
        }

        public static IServiceCollection AddEmarsysProdutoService(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<EmarsysCredencialProvider>();
            services.AddScoped<ExcelTemplateProvider>();

            services.AddScoped<IFileExporter<ProdutoDto>, CsvProdutoExporter>();
            services.AddScoped<IEmarsysProdutoService, EmarsysProdutoService>();

            return services;
        }
    }
}
