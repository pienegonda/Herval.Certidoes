using System.Collections.Generic;
using System.Linq;
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Requests;

namespace Herval.Emarsys.Sdk.Mappers
{
    internal static class AnexoEmailEmarsysRequestMapper
    {
        internal static IEnumerable<AnexoEmailEmarsysRequest> Map(List<AnexoEmailDto> anexos)
        {
            return anexos?.Select(x => new AnexoEmailEmarsysRequest
            {
                NomeArquivo = x.NomeArquivo,
                ArquivoBase64 = x.ArquivoBase64
            });
        }
    }
}
