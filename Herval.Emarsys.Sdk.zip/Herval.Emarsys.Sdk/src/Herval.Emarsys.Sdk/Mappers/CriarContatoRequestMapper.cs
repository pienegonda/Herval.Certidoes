using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Enums;
using Herval.Emarsys.Sdk.Requests;
using System.Collections.Generic;
using System.Linq;

namespace Herval.Emarsys.Sdk.Mappers
{
    internal static class CriarContatoRequestMapper
    {
        internal static CriarContatoEmarsysRequest Map<T>(ENegocio negocio, IEnumerable<T> contatos) where T : ContatoBaseDto
        {
            var contatosList = contatos.ToList();
            if (!contatosList.Any())
            {
                throw new System.ArgumentException("A lista de contatos não pode estar vazia.", nameof(contatos));
            }

            var primeiroContato = contatosList.First();

            return primeiroContato switch
            {
                CriarContatoCorretoraDto => CriarContatoCorretoraEmarsysRequestMapper.Map(contatosList.Cast<CriarContatoCorretoraDto>().ToArray()),
                CriarContatoConsorcioDto => CriarContatoConsorcioEmarsysRequestMapper.Map(negocio, contatosList.Cast<CriarContatoConsorcioDto>().ToArray()),
                CriarContatoHervalDto => CriarContatoEmarsysRequestMapper.Map(negocio, contatosList.Cast<CriarContatoHervalDto>().ToArray()),
                _ => throw new System.NotImplementedException($"Mapper para o tipo {primeiroContato.GetType().Name} não implementado.")
            };
        }
    }
}