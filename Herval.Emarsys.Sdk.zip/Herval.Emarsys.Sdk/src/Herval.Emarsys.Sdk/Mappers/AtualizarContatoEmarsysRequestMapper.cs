using System;
using System.Collections.Generic;
using Herval.Emarsys.Sdk.Constants;
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Enums;
using Herval.Emarsys.Sdk.Requests;

namespace Herval.Emarsys.Sdk.Mappers
{
    internal class AtualizarContatoEmarsysRequestMapper
    {
        internal static CriarContatoEmarsysRequest Map(AtualizarContatoDto atualizarContatoDto)
        {
            if (atualizarContatoDto is null)
                throw new ArgumentNullException(nameof(atualizarContatoDto), "O DTO de atualização de cliente não pode ser nulo.");

            if (atualizarContatoDto.Documento?.IsValid is false && string.IsNullOrEmpty(atualizarContatoDto.DocumentoEstrangeiro))
                throw new ArgumentNullException(nameof(atualizarContatoDto), "Documento informado é inválido.");

            return new CriarContatoEmarsysRequest
            {
                ChaveEnvio = ObterCodigoChaveDocumento(atualizarContatoDto.Negocio),
                Dados = new List<Dictionary<string, string>> { MapearDados(atualizarContatoDto) }
            };
        }

        private static Dictionary<string, string> MapearDados(AtualizarContatoDto atualizarContatoDto)
        {
            var codigoChaveDocumento = ObterCodigoChaveDocumento(atualizarContatoDto.Negocio);
            var codigoChaveIdade = ObterCodigoChaveIdade(atualizarContatoDto.Negocio);

            var dado = new Dictionary<string, string>();

            void AdicionarSePossuiValor(string key, string value)
            {
                if (!string.IsNullOrEmpty(value))
                    dado[key] = value;
            }

            AdicionarSePossuiValor(codigoChaveDocumento, atualizarContatoDto.Documento?.Numero ?? atualizarContatoDto.DocumentoEstrangeiro);
            AdicionarSePossuiValor(ChaveContato.Nome, atualizarContatoDto.Nome);
            AdicionarSePossuiValor(ChaveContato.Sobrenome, atualizarContatoDto.Sobrenome);
            AdicionarSePossuiValor(ChaveContato.Email, atualizarContatoDto.Email?.Completo);
            AdicionarSePossuiValor(ChaveContato.EstadoCivil, atualizarContatoDto.EstadoCivil.HasValue ? ((int)atualizarContatoDto.EstadoCivil.Value).ToString() : null);
            AdicionarSePossuiValor(ChaveContato.Genero, atualizarContatoDto.Genero.HasValue ? ((int)atualizarContatoDto.Genero).ToString() : null);
            AdicionarSePossuiValor(ChaveContato.Endereco, atualizarContatoDto.Endereco);
            AdicionarSePossuiValor(ChaveContato.Cidade, atualizarContatoDto.Cidade);
            AdicionarSePossuiValor(ChaveContato.Estado, atualizarContatoDto.Estado);
            AdicionarSePossuiValor(ChaveContato.CEP, atualizarContatoDto.CEP?.Numero);
            AdicionarSePossuiValor(ChaveContato.Regiao, atualizarContatoDto.PaisOrigem.HasValue ? ((int)atualizarContatoDto.PaisOrigem).ToString() : null);
            AdicionarSePossuiValor(ChaveContato.Celular, atualizarContatoDto.Telefone?.Numero);
            AdicionarSePossuiValor(ChaveContato.DataNascimento, atualizarContatoDto.DataNascimento.HasValue ? atualizarContatoDto.DataNascimento.Value.ToString("yyyy-MM-dd") : null);
            AdicionarSePossuiValor(codigoChaveIdade, atualizarContatoDto.Idade.ToString());
            AdicionarSePossuiValor(ChaveContato.Filhos, ObterValorFilhosEmarsys(atualizarContatoDto.Filhos));
            AdicionarSePossuiValor(ChaveContato.Escolaridade, atualizarContatoDto.Escolaridade.HasValue ? ((int)atualizarContatoDto.Escolaridade).ToString() : null);
            AdicionarSePossuiValor(ChaveContato.Departamento, atualizarContatoDto.Departamento.HasValue ? ((int)atualizarContatoDto.Departamento).ToString() : null);
            AdicionarSePossuiValor(ChaveContato.Industria, atualizarContatoDto.Industria.HasValue ? ((int)atualizarContatoDto.Industria).ToString() : null);
            AdicionarSePossuiValor(ChaveContato.TelefoneEmpresa, atualizarContatoDto.TelefoneEmpresa?.Numero);
            AdicionarSePossuiValor(ChaveContato.FaxEmpresa, atualizarContatoDto.FaxEmpresa);
            AdicionarSePossuiValor(ChaveContato.NumeroFuncionarios, ObterValorNumeroFuncionariosEmarsys(atualizarContatoDto.NumeroFuncionarios));
            AdicionarSePossuiValor(ChaveContato.ReceitaAnual, ObterValorReceitaAnualEmarsys(atualizarContatoDto.ReceitaAnual));
            AdicionarSePossuiValor(ChaveContato.SiteEmpresa, atualizarContatoDto.SiteEmpresa);
            AdicionarSePossuiValor(ChaveContato.CargoEmpresa, atualizarContatoDto.CargoEmpresa.HasValue ? ((int)atualizarContatoDto.CargoEmpresa).ToString() : null);
            AdicionarSePossuiValor(ChaveContato.PrimeiroNomeConjugue, atualizarContatoDto.PrimeiroNomeConjugue);
            AdicionarSePossuiValor(ChaveContato.DataNascimentoConjugue, atualizarContatoDto.DataNascimentoConjugue.HasValue ? atualizarContatoDto.DataNascimentoConjugue.Value.ToString("yyyy-MM-dd") : null);
            AdicionarSePossuiValor(ChaveContato.Aniversario, atualizarContatoDto.Aniversario.HasValue ? atualizarContatoDto.Aniversario.Value.ToString("yyyy-MM-dd") : null);
            AdicionarSePossuiValor(ChaveContato.EnderecoEmpresa, atualizarContatoDto.EnderecoEmpresa);
            AdicionarSePossuiValor(ChaveContato.CEPEmpresa, atualizarContatoDto.CEPEmpresa);
            AdicionarSePossuiValor(ChaveContato.CidadeEmpresa, atualizarContatoDto.CidadeEmpresa);
            AdicionarSePossuiValor(ChaveContato.EstadoEmpresa, atualizarContatoDto.EstadoEmpresa);
            AdicionarSePossuiValor(ChaveContato.RegiaoEmpresa, atualizarContatoDto.RegiaoEmpresa.HasValue ? ((int)atualizarContatoDto.RegiaoEmpresa).ToString() : null);
            AdicionarSePossuiValor(ChaveContato.FuncionarioAtivo, atualizarContatoDto.FuncionarioAtivo.HasValue ? atualizarContatoDto.FuncionarioAtivo.Value.ToString() : null);
            AdicionarSePossuiValor(ChaveContato.MatriculaFuncionario, atualizarContatoDto.MatriculaFuncionario);
            AdicionarSePossuiValor(ChaveContato.DataDemissaoFuncionario, atualizarContatoDto.DataDemissaoFuncionario.HasValue ? atualizarContatoDto.DataDemissaoFuncionario.Value.ToString("yyyy-MM-dd") : null);
            AdicionarSePossuiValor(ChaveContato.AceitaContatoWhatsApp, ObterValorAceitaContatoWhatsAppEmarsys(atualizarContatoDto.AceitaContatoWhatsApp));

            if (atualizarContatoDto.Negocio is ENegocio.HsFinanceira)
            {
                AdicionarSePossuiValor(ChaveContato.LimiteGlobal, atualizarContatoDto.LimiteGlobal?.ToString());
                AdicionarSePossuiValor(ChaveContato.LimiteIplaceHoje, atualizarContatoDto.LimiteIplaceHoje?.ToString());
                AdicionarSePossuiValor(ChaveContato.LimiteCDC, atualizarContatoDto.LimiteCDC?.ToString());
                AdicionarSePossuiValor(ChaveContato.LimiteParcela, atualizarContatoDto.LimiteParcela?.ToString());
            }

            return dado;
        }

        private static string ObterCodigoChaveDocumento(ENegocio negocio)
        {
            return negocio switch
            {
                ENegocio.Herval => ChaveContato.DocumentoHerval,
                ENegocio.Iplace => ChaveContato.DocumentoIplace,
                ENegocio.IplaceCorp => ChaveContato.DocumentoIplaceCorp,
                ENegocio.IplaceUY => ChaveContato.DocumentoIplaceUY,
                ENegocio.Taqi => ChaveContato.DocumentoTaqi,
                ENegocio.TaqiCorp => ChaveContato.DocumentoTaqiCorp,
                ENegocio.HsConsorcio => ChaveContato.DocumentoHSConsorcio,
                ENegocio.HsFinanceira => ChaveContato.DocumentoHSFinanceira,
                ENegocio.HTSolutions => ChaveContato.DocumentoHTSolutions,
                ENegocio.VouLevar => ChaveContato.DocumentoVoulevar,
                ENegocio.Volis => ChaveContato.DocumentoVolis,
                ENegocio.UUltis => ChaveContato.DocumentoUultis,
                ENegocio.MisterTech => ChaveContato.DocumentoMistertech,
                _ => throw new ArgumentException("Negócio não suportado para atualização de contato.", nameof(negocio))
            };
        }

        private static string ObterCodigoChaveIdade(ENegocio negocio)
        {
            return negocio switch
            {
                ENegocio.Herval => ChaveContato.IdadeHerval,
                ENegocio.Iplace => ChaveContato.IdadeIplace,
                ENegocio.IplaceCorp => ChaveContato.IdadeIplaceCorp,
                ENegocio.IplaceUY => ChaveContato.IdadeIplaceUY,
                ENegocio.Taqi => ChaveContato.IdadeTaqi,
                ENegocio.TaqiCorp => ChaveContato.IdadeTaqiCorp,
                ENegocio.HsConsorcio => ChaveContato.IdadeHSConsorcio,
                ENegocio.HsFinanceira => ChaveContato.IdadeHSFinanceira,
                ENegocio.HTSolutions => ChaveContato.IdadeHTSolutions,
                ENegocio.VouLevar => ChaveContato.IdadeVoulevar,
                ENegocio.Volis => ChaveContato.IdadeVolis,
                ENegocio.UUltis => ChaveContato.IdadeUultis,
                ENegocio.MisterTech => ChaveContato.IdadeMistertech,
                _ => throw new ArgumentException("Negócio não suportado para atualização de contato.", nameof(negocio))
            };
        }

        private static string ObterValorFilhosEmarsys(int? filhos)
        {
            return filhos switch
            {
                null => null,
                0 => ((int)EFilhoContato.Nenhum).ToString(),
                1 => ((int)EFilhoContato.Um).ToString(),
                2 => ((int)EFilhoContato.Dois).ToString(),
                3 => ((int)EFilhoContato.Tres).ToString(),
                > 3 => ((int)EFilhoContato.QuatroOuMais).ToString(),
            };
        }

        private static string ObterValorNumeroFuncionariosEmarsys(int? numeroFuncionarios)
        {
            return numeroFuncionarios switch
            {
                null => ((int)ENumeroFuncionariosContato.SemInformacao).ToString(),
                <= 9 => ((int)ENumeroFuncionariosContato.EntreUmENove).ToString(),
                <= 49 => ((int)ENumeroFuncionariosContato.EntreDezEQuarentaENove).ToString(),
                <= 99 => ((int)ENumeroFuncionariosContato.EntreCinquentaENoventaENove).ToString(),
                <= 249 => ((int)ENumeroFuncionariosContato.EntreCemEDuzentosQuarentaENove).ToString(),
                <= 499 => ((int)ENumeroFuncionariosContato.EntreDuzentosECinquentaEQuatrocentosENoventaENove).ToString(),
                <= 999 => ((int)ENumeroFuncionariosContato.EntreQuinhentosENovecentosENoventaENove).ToString(),
                <= 2499 => ((int)ENumeroFuncionariosContato.EntreMilEDoisMilQuatrocentosENoventaENove).ToString(),
                <= 9999 => ((int)ENumeroFuncionariosContato.EntreDoisMilQuinhentosENoveMilENovecentosENoventaENove).ToString(),
                _ => ((int)ENumeroFuncionariosContato.AcimaDeDezMil).ToString()
            };
        }

        private static string ObterValorReceitaAnualEmarsys(decimal? receitaAnual)
        {
            return receitaAnual switch
            {
                null => ((int)EReceitaAnualContato.SemInformacao).ToString(),
                < 99 => ((int)EReceitaAnualContato.MenosDeNoventaENove).ToString(),
                < 249 => ((int)EReceitaAnualContato.EntreCemEDuzentosQuarentaENove).ToString(),
                < 499 => ((int)EReceitaAnualContato.EntreDuzentosECinquentaEQuatrocentosENoventaENove).ToString(),
                < 999 => ((int)EReceitaAnualContato.EntreQuinhentosENovecentosENoventaENove).ToString(),
                < 2499 => ((int)EReceitaAnualContato.EntreMilEDoisMilQuatrocentosENoventaENove).ToString(),
                < 9999 => ((int)EReceitaAnualContato.EntreDoisMilQuinhentosENoveMilENovecentosENoventaENove).ToString(),
                _ => ((int)EReceitaAnualContato.AcimaDeDezMil).ToString()
            };
        }

        private static string ObterValorAceitaContatoWhatsAppEmarsys(bool? aceitaContatoWhatsApp)
        {
            return aceitaContatoWhatsApp switch
            {
                null => null,
                true => ((int) EAceitaContatoWhatsApp.Sim).ToString(),
                false => ((int) EAceitaContatoWhatsApp.Nao).ToString(),
            };
        }
    }
}