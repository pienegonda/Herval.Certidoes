using System;
using System.Collections.Generic;
using System.Linq;
using Herval.Emarsys.Sdk.Constants;
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Requests;
using Herval.Extensions.IEnumerables;

namespace Herval.Emarsys.Sdk.Mappers
{
    internal static class CriarContatoCorretoraEmarsysRequestMapper
    {
        internal static CriarContatoEmarsysRequest Map(IEnumerable<CriarContatoCorretoraDto>  criarContatoCorretoraDto)
        {
            if (criarContatoCorretoraDto.IsNullOrEmpty())
            {
                throw new ArgumentNullException(nameof(criarContatoCorretoraDto), "O DTO de criação de contato não pode ser nulo.");
            }

            if (criarContatoCorretoraDto.Any(doc => doc.Documento?.IsValid is false))
            {
                throw new ArgumentNullException(nameof(criarContatoCorretoraDto), "Documento informado é inválido.");
            }

            return new CriarContatoEmarsysRequest
            {
                ChaveEnvio = ChaveContato.DocumentoCliente,
                Dados = criarContatoCorretoraDto.Select(MapearDados).ToList()
            };
        }

        private static Dictionary<string, string> MapearDados(CriarContatoCorretoraDto criarContatoDto)
        {
            var dado = new Dictionary<string, string>
            {
                { ChaveContato.Nome, criarContatoDto.Nome },
                { ChaveContato.Sobrenome, criarContatoDto.Sobrenome },
                { ChaveContato.CodigoCliente, criarContatoDto.CodigoCliente },
                { ChaveContato.ClienteAtivo, criarContatoDto.ClienteAtivo ? "1" : "0" },
                { ChaveContato.DocumentoCliente, criarContatoDto.Documento.Numero },
                { ChaveContato.DataNascimento, criarContatoDto.DataNascimento?.ToString("yyyy-MM-dd") },
                { ChaveContato.TipoPessoa, criarContatoDto.TipoPessoa },
                { ChaveContato.Genero, criarContatoDto.Genero.HasValue ? ((int)criarContatoDto.Genero.Value).ToString() : null },
                { ChaveContato.Email, criarContatoDto.Email?.Completo },
                { ChaveContato.Celular, criarContatoDto.Telefone?.Numero },
                { ChaveContato.Cidade, criarContatoDto.Cidade },
                { ChaveContato.Estado, criarContatoDto.Estado },
                { ChaveContato.ClienteVigente, criarContatoDto.ClienteVigente ? "1" : "0" }
            };

            return dado;
        }
    }
}