﻿using Herval.Emarsys.Sdk.Constants;
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Enums;
using Herval.Emarsys.Sdk.Requests;
using System;

namespace Herval.Emarsys.Sdk.Mappers
{
    internal class CriarFormsEmarsysRequestMapper
    {
        internal static CriarFormsEmarsysRequest Map(CriarFormsDto dto)
        {
            if (dto is null)
                throw new ArgumentNullException(nameof(dto), "O DTO de criação de contato não pode ser nulo.");

            var chaveEnvio = ObterChaveEnvio(dto);
            var identificacao = ObterIdentificacao(dto);

            return new CriarFormsEmarsysRequest
            {
                ChaveEnvio = chaveEnvio,
                Identificacao = identificacao
            };
        }

        private static string ObterChaveEnvio(CriarFormsDto dto)
        {
            if (dto.Email != null)
                return ChaveContato.Email;

            if (dto.Telefone != null)
                return ChaveContato.Celular;

            if (dto.Documento != null)
                return ObterChaveDocumentoPorNegocio(dto.Negocio);

            throw new InvalidOperationException("É necessário informar pelo menos um identificador: Email, Telefone ou Documento.");
        }

        private static string ObterIdentificacao(CriarFormsDto dto)
        {
            return dto.Email?.Completo
                ?? dto.Telefone?.Numero
                ?? dto.Documento?.Numero;
        }

        private static string ObterChaveDocumentoPorNegocio(ENegocio negocio) =>
            negocio switch
            {
                ENegocio.Herval => ChaveContato.DocumentoHerval,
                ENegocio.Iplace => ChaveContato.DocumentoIplace,
                ENegocio.IplaceCorp => ChaveContato.DocumentoIplaceCorp,
                ENegocio.IplaceUY => ChaveContato.DocumentoIplaceUY,
                ENegocio.Taqi => ChaveContato.DocumentoTaqi,
                ENegocio.TaqiCorp => ChaveContato.DocumentoTaqiCorp,
                ENegocio.HsConsorcio => ChaveContato.DocumentoHSConsorcio,
                ENegocio.HsFinanceira => ChaveContato.DocumentoHSFinanceira,
                ENegocio.HTSolutions => ChaveContato.DocumentoHTSolutions,
                ENegocio.VouLevar => ChaveContato.DocumentoVoulevar,
                ENegocio.Volis => ChaveContato.DocumentoVolis,
                ENegocio.UUltis => ChaveContato.DocumentoUultis,
                ENegocio.MisterTech => ChaveContato.DocumentoMistertech,
                _ => throw new ArgumentOutOfRangeException(nameof(negocio), "Negócio não suportado para registro de lead.")
            };
    }
}
