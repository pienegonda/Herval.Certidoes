﻿using Herval.Emarsys.Sdk.Constants;
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Enums;
using Herval.Emarsys.Sdk.Requests;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Herval.Emarsys.Sdk.Mappers
{
    internal static class CriarContatoEmarsysRequestMapper
    {
        internal static CriarContatoEmarsysRequest Map(ENegocio negocio, IEnumerable<CriarContatoHervalDto> criarContatoHervalDto)
        {
            if (criarContatoHervalDto == null)
            {
                throw new ArgumentNullException(nameof(criarContatoHervalDto), "O DTO de criação de contato não pode ser nulo.");
            }

            if (criarContatoHervalDto.Any(d => d.Documento?.IsValid is false && string.IsNullOrEmpty(d.DocumentoEstrangeiro)))
            {
                throw new ArgumentNullException(nameof(criarContatoHervalDto), "Documento informado é inválido.");
            }

            return new CriarContatoEmarsysRequest
            {
                ChaveEnvio = ObterCodigoChaveDocumento(negocio),
                Dados = criarContatoHervalDto.Select(contato => MapearDados(negocio, contato)).ToList()
            };
        }

        private static Dictionary<string, string> MapearDados(ENegocio negocio, CriarContatoHervalDto contato)
        {
            if (contato == null)
            {
                throw new ArgumentNullException(nameof(contato), "O contato não pode ser nulo.");
            }

            var codigoChaveDocumento = ObterCodigoChaveDocumento(negocio);
            var codigoChaveIdade = ObterCodigoChaveIdade(negocio);

            var dado = new Dictionary<string, string>
            {
                { codigoChaveDocumento, contato.Documento?.Numero ?? contato.DocumentoEstrangeiro },
                { ChaveContato.Nome, contato.Nome },
                { ChaveContato.Sobrenome, contato.Sobrenome },
                { ChaveContato.Email, contato.Email?.Completo },
                { ChaveContato.EstadoCivil, contato.EstadoCivil.HasValue ? ((int)contato.EstadoCivil.Value).ToString() : null },
                { ChaveContato.Genero, contato.Genero.HasValue ? ((int)contato.Genero).ToString() : null },
                { ChaveContato.Endereco, contato.Endereco },
                { ChaveContato.Cidade, contato.Cidade },
                { ChaveContato.Estado, contato.Estado },
                { ChaveContato.CEP, contato.CEP?.Numero },
                { ChaveContato.Regiao, contato.PaisOrigem.HasValue ? ((int)contato.PaisOrigem).ToString() : null },
                { ChaveContato.Celular, contato.Telefone?.Numero },
                { ChaveContato.DataNascimento, contato.DataNascimento.HasValue ? contato.DataNascimento.Value.ToString("yyyy-MM-dd") : null },
                { codigoChaveIdade, contato.Idade.ToString() },
                { ChaveContato.Filhos, ObterValorFilhosEmarsys(contato.Filhos) },
                { ChaveContato.Escolaridade, contato.Escolaridade.HasValue ? ((int)contato.Escolaridade).ToString() : null },
                { ChaveContato.Departamento, contato.Departamento.HasValue ? ((int)contato.Departamento).ToString() : null },
                { ChaveContato.Industria, contato.Industria.HasValue ? ((int)contato.Industria).ToString() : null },
                { ChaveContato.TelefoneEmpresa, contato.TelefoneEmpresa?.Numero },
                { ChaveContato.FaxEmpresa, contato.FaxEmpresa },
                { ChaveContato.NumeroFuncionarios, ObterValorNumeroFuncionariosEmarsys(contato.NumeroFuncionarios) },
                { ChaveContato.ReceitaAnual, ObterValorReceitaAnualEmarsys(contato.ReceitaAnual) },
                { ChaveContato.SiteEmpresa, contato.SiteEmpresa },
                { ChaveContato.CargoEmpresa, contato.CargoEmpresa.HasValue ? ((int)contato.CargoEmpresa).ToString() : null },
                { ChaveContato.PrimeiroNomeConjugue, contato.PrimeiroNomeConjugue },
                { ChaveContato.DataNascimentoConjugue, contato.DataNascimentoConjugue.HasValue ? contato.DataNascimentoConjugue.Value.ToString("yyyy-MM-dd") : null },
                { ChaveContato.Aniversario, contato.Aniversario.HasValue ? contato.Aniversario.Value.ToString("yyyy-MM-dd") : null },
                { ChaveContato.EnderecoEmpresa, contato.EnderecoEmpresa },
                { ChaveContato.CEPEmpresa, contato.CEPEmpresa },
                { ChaveContato.CidadeEmpresa, contato.CidadeEmpresa },
                { ChaveContato.EstadoEmpresa, contato.EstadoEmpresa },
                { ChaveContato.RegiaoEmpresa, contato.RegiaoEmpresa.HasValue ? ((int)contato.RegiaoEmpresa).ToString() : null },
                { ChaveContato.FuncionarioAtivo, contato.FuncionarioAtivo.HasValue ? contato.FuncionarioAtivo.Value.ToString() : null },
                { ChaveContato.MatriculaFuncionario, contato.MatriculaFuncionario },
                { ChaveContato.DataDemissaoFuncionario, contato.DataDemissaoFuncionario.HasValue ? contato.DataDemissaoFuncionario.Value.ToString("yyyy-MM-dd") : null },
                { ChaveContato.AceitaContatoWhatsApp, ObterValorAceitaContatoWhatsAppEmarsys(contato.AceitaContatoWhatsApp) }
            };

            return dado;
        }

        private static string ObterValorNumeroFuncionariosEmarsys(int? numeroFuncionarios)
        {
            return numeroFuncionarios switch
            {
                null => ((int)ENumeroFuncionariosContato.SemInformacao).ToString(),
                <= 9 => ((int)ENumeroFuncionariosContato.EntreUmENove).ToString(),
                <= 49 => ((int)ENumeroFuncionariosContato.EntreDezEQuarentaENove).ToString(),
                <= 99 => ((int)ENumeroFuncionariosContato.EntreCinquentaENoventaENove).ToString(),
                <= 249 => ((int)ENumeroFuncionariosContato.EntreCemEDuzentosQuarentaENove).ToString(),
                <= 499 => ((int)ENumeroFuncionariosContato.EntreDuzentosECinquentaEQuatrocentosENoventaENove).ToString(),
                <= 999 => ((int)ENumeroFuncionariosContato.EntreQuinhentosENovecentosENoventaENove).ToString(),
                <= 2499 => ((int)ENumeroFuncionariosContato.EntreMilEDoisMilQuatrocentosENoventaENove).ToString(),
                <= 9999 => ((int)ENumeroFuncionariosContato.EntreDoisMilQuinhentosENoveMilENovecentosENoventaENove).ToString(),
                _ => ((int)ENumeroFuncionariosContato.AcimaDeDezMil).ToString()
            };
        }

        private static string ObterValorReceitaAnualEmarsys(decimal? receitaAnual)
        {
            return receitaAnual switch
            {
                null => ((int)EReceitaAnualContato.SemInformacao).ToString(),
                < 99 => ((int)EReceitaAnualContato.MenosDeNoventaENove).ToString(),
                < 249 => ((int)EReceitaAnualContato.EntreCemEDuzentosQuarentaENove).ToString(),
                < 499 => ((int)EReceitaAnualContato.EntreDuzentosECinquentaEQuatrocentosENoventaENove).ToString(),
                < 999 => ((int)EReceitaAnualContato.EntreQuinhentosENovecentosENoventaENove).ToString(),
                < 2499 => ((int)EReceitaAnualContato.EntreMilEDoisMilQuatrocentosENoventaENove).ToString(),
                < 9999 => ((int)EReceitaAnualContato.EntreDoisMilQuinhentosENoveMilENovecentosENoventaENove).ToString(),
                _ => ((int)EReceitaAnualContato.AcimaDeDezMil).ToString()
            };
        }

        private static string ObterValorFilhosEmarsys(int? filhos)
        {
            return filhos switch
            {
                null => null,
                0 => ((int)EFilhoContato.Nenhum).ToString(),
                1 => ((int)EFilhoContato.Um).ToString(),
                2 => ((int)EFilhoContato.Dois).ToString(),
                3 => ((int)EFilhoContato.Tres).ToString(),
                > 3 => ((int)EFilhoContato.QuatroOuMais).ToString(),
                _ => null
            };
        }

        private static string ObterCodigoChaveDocumento(ENegocio negocio)
        {
            return negocio switch
            {
                ENegocio.Herval => ChaveContato.DocumentoHerval,
                ENegocio.Iplace => ChaveContato.DocumentoIplace,
                ENegocio.IplaceCorp => ChaveContato.DocumentoIplaceCorp,
                ENegocio.IplaceUY => ChaveContato.DocumentoIplaceUY,
                ENegocio.Taqi => ChaveContato.DocumentoTaqi,
                ENegocio.TaqiCorp => ChaveContato.DocumentoTaqiCorp,
                ENegocio.HsConsorcio => ChaveContato.DocumentoHSConsorcio,
                ENegocio.HsFinanceira => ChaveContato.DocumentoHSFinanceira,
                ENegocio.HTSolutions => ChaveContato.DocumentoHTSolutions,
                ENegocio.VouLevar => ChaveContato.DocumentoVoulevar,
                ENegocio.Volis => ChaveContato.DocumentoVolis,
                ENegocio.UUltis => ChaveContato.DocumentoUultis,
                ENegocio.MisterTech => ChaveContato.DocumentoMistertech,
                _ => throw new ArgumentException("Negócio não suportado para criação de contato.", nameof(negocio))
            };
        }

        private static string ObterCodigoChaveIdade(ENegocio negocio)
        {
            return negocio switch
            {
                ENegocio.Herval => ChaveContato.IdadeHerval,
                ENegocio.Iplace => ChaveContato.IdadeIplace,
                ENegocio.IplaceCorp => ChaveContato.IdadeIplaceCorp,
                ENegocio.IplaceUY => ChaveContato.IdadeIplaceUY,
                ENegocio.Taqi => ChaveContato.IdadeTaqi,
                ENegocio.TaqiCorp => ChaveContato.IdadeTaqiCorp,
                ENegocio.HsConsorcio => ChaveContato.IdadeHSConsorcio,
                ENegocio.HsFinanceira => ChaveContato.IdadeHSFinanceira,
                ENegocio.HTSolutions => ChaveContato.IdadeHTSolutions,
                ENegocio.VouLevar => ChaveContato.IdadeVoulevar,
                ENegocio.Volis => ChaveContato.IdadeVolis,
                ENegocio.UUltis => ChaveContato.IdadeUultis,
                ENegocio.MisterTech => ChaveContato.IdadeMistertech,
                _ => throw new ArgumentException("Negócio não suportado para criação de contato.", nameof(negocio))
            };
        }

        private static string ObterValorAceitaContatoWhatsAppEmarsys(bool? aceitaContatoWhatsApp)
        {
            return aceitaContatoWhatsApp switch
            {
                null => null,
                true => ((int)EAceitaContatoWhatsApp.Sim).ToString(),
                false => ((int)EAceitaContatoWhatsApp.Nao).ToString(),
            };
        }
    }
}
