﻿using Herval.Emarsys.Sdk.Constants;
using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Enums;
using Herval.Emarsys.Sdk.Requests;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Herval.Emarsys.Sdk.Mappers
{
    internal static class EnviarEventoEmarsysRequestMapper
    {
        internal static EnviarEventoMultiploEmarsysRequest Map(EnviarEventoDto enviarEventoDto)
        {
            var emails = string.IsNullOrWhiteSpace(enviarEventoDto.EmailDestinatario)
                    ? Array.Empty<string>()
                    : enviarEventoDto.EmailDestinatario.Split(',', StringSplitOptions.RemoveEmptyEntries)
                        .Select(e => e.Trim())
                        .Where(e => !string.IsNullOrWhiteSpace(e))
                        .ToArray();

            if (emails.Length > 0)
            {
                return new EnviarEventoMultiploEmarsysRequest
                {
                    ChaveEnvio = ((int)EChaveEnvio.Email).ToString(),
                    Contatos = emails.Select(email => new EnviarEventoEmarsysRequest
                        {
                            Identificacao = email,
                            Dados = enviarEventoDto.Dados,
                            Anexos = AnexoEmailEmarsysRequestMapper.Map(enviarEventoDto?.Anexos)
                        }
                    )
                };
            }
            else
            {
                return new EnviarEventoMultiploEmarsysRequest
                {
                    ChaveEnvio = ObterCodigoChaveCPF(enviarEventoDto.Negocio),
                    Contatos = new List<EnviarEventoEmarsysRequest>
                    {
                        new() {
                            Identificacao = enviarEventoDto.DocumentoDestinatario,
                            Dados = enviarEventoDto.Dados,
                            Anexos = AnexoEmailEmarsysRequestMapper.Map(enviarEventoDto?.Anexos)
                        }
                    }
                };
            }
        }

        private static string ObterCodigoChaveCPF(ENegocio negocio)
        {
            return negocio switch
            {
                ENegocio.Herval => ChaveContato.DocumentoHerval,
                ENegocio.Iplace => ChaveContato.DocumentoIplace,
                ENegocio.IplaceCorp => ChaveContato.DocumentoIplaceCorp,
                ENegocio.IplaceUY => ChaveContato.DocumentoIplaceUY,
                ENegocio.Taqi => ChaveContato.DocumentoTaqi,
                ENegocio.TaqiCorp => ChaveContato.DocumentoTaqiCorp,
                ENegocio.HsConsorcio => ChaveContato.DocumentoHSConsorcio,
                ENegocio.HsFinanceira => ChaveContato.DocumentoHSFinanceira,
                ENegocio.HTSolutions => ChaveContato.DocumentoHTSolutions,
                ENegocio.VouLevar => ChaveContato.DocumentoVoulevar,
                ENegocio.Volis => ChaveContato.DocumentoVolis,
                ENegocio.UUltis => ChaveContato.DocumentoUultis,
                ENegocio.MisterTech => ChaveContato.DocumentoMistertech,
                _ => throw new ArgumentException("Negócio não suportado para criação de contato.", nameof(negocio))
            };
        }
    }
}
