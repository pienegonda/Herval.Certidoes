﻿using System;

namespace Herval.Emarsys.Sdk.Dtos
{
    public class ConsorcioDto : VendaBaseDto
    {
        public string CotaId { get; private set; }
        public DateTime DataVenda { get; private set; }
        public string Documento { get; private set; }
        public string Bem { get; private set; }
        public decimal ValorBem { get; private set; }
        public decimal ValorParcela { get; private set; }
        public int QuantidadeParcelas { get; private set; }
        public string Tipo { get; private set; }
        public string Versao { get; private set; }
        public string CodigoGrupo { get; private set; }
        public DateTime DataEncerramento { get; private set; }
        public string CodigoCota { get; private set; }
        public int QuantidadeCotas { get; private set; }
        public string CorretoraId { get; private set; }
        public string NomeCorretora { get; private set; }
        public string VendedorId { get; private set; }
        public string NomeVendedor { get; private set; }
        public string CidadeCorretora { get; private set; }
        public string EstadoCorretora { get; private set; }

        public ConsorcioDto(
            string cotaId,
            DateTime dataVenda,
            string documento,
            string bem,
            decimal valorBem,
            decimal valorParcela,
            int quantidadeParcelas,
            string tipo,
            string versao,
            string codigoGrupo,
            DateTime dataEncerramento,
            string codigoCota,
            int quantidadeCotas,
            string corretoraId,
            string nomeCorretora,
            string vendedorId,
            string nomeVendedor,
            string cidadeCorretora,
            string estadoCorretora)
        {
            CotaId = cotaId;
            DataVenda = dataVenda;
            Documento = documento;
            Bem = bem;
            ValorBem = valorBem;
            ValorParcela = valorParcela;
            QuantidadeParcelas = quantidadeParcelas;
            Tipo = tipo;
            Versao = versao;
            CodigoGrupo = codigoGrupo;
            DataEncerramento = dataEncerramento;
            CodigoCota = codigoCota;
            QuantidadeCotas = quantidadeCotas;
            CorretoraId = corretoraId;
            NomeCorretora = nomeCorretora;
            VendedorId = vendedorId;
            NomeVendedor = nomeVendedor;
            CidadeCorretora = cidadeCorretora;
            EstadoCorretora = estadoCorretora;
        }
    }
}
