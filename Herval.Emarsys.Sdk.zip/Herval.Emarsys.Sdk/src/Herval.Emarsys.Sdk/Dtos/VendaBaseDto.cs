namespace Herval.Emarsys.Sdk.Dtos
{

    public abstract class VendaBaseDto
    {

    }
}