using System;

namespace Herval.Emarsys.Sdk.Dtos
{
    public class FinanceiraDto : VendaBaseDto
    {
        public string IdentificadorLoja { get; private set; }
        public string NomeLoja { get; private set; }
        public string CidadeVenda { get; private set; }
        public string UfLoja { get; private set; }
        public string IdentificadorInterno { get; private set; }
        public DateTime DataProcessamento { get; private set; }
        public DateTime DataTransacao { get; private set; }
        public decimal? PrecoTotal { get; private set; }
        public string Cliente { get; private set; }
        public long? CanalVendas { get; private set; }
        public long? QuantidadeParcelas { get; private set; }
        public long? ProdutoId { get; private set; }
        public string DescricaoProduto { get; private set; }
        public string Moeda { get; private set; }
        public decimal? ValorOriginal { get; private set; }
        public long? QuantidadeItemFinanceiro { get; private set; }
        public DateTime DataCriacao { get; private set; }

        public FinanceiraDto(
            string identificadorLoja,
            string nomeLoja,
            string cidadeVenda,
            string ufLoja,
            string identificadorInterno,
            DateTime dataProcessamento,
            DateTime dataTransacao,
            decimal? precoTotal,
            string cliente,
            long? canalVendas,
            long? quantidadeParcelas,
            long? produtoId,
            string descricaoProduto,
            string moeda,
            decimal? valorOriginal,
            long? quantidadeItemFinanceiro,
            DateTime dataCriacao)
        {
            IdentificadorLoja = identificadorLoja;
            NomeLoja = nomeLoja;
            CidadeVenda = cidadeVenda;
            UfLoja = ufLoja;
            IdentificadorInterno = identificadorInterno;
            DataProcessamento = dataProcessamento;
            DataTransacao = dataTransacao;
            PrecoTotal = precoTotal;
            Cliente = cliente;
            CanalVendas = canalVendas;
            QuantidadeParcelas = quantidadeParcelas;
            ProdutoId = produtoId;
            DescricaoProduto = descricaoProduto;
            Moeda = moeda;
            ValorOriginal = valorOriginal;
            QuantidadeItemFinanceiro = quantidadeItemFinanceiro;
            DataCriacao = dataCriacao;
        }
    }
}