using System;
using Herval.Emarsys.Sdk.Enums;
using Herval.ValueObjects.Objects;

namespace Herval.Emarsys.Sdk.Dtos
{
    public class CriarContatoCorretoraDto : ContatoBaseDto
    {
        public string CodigoCliente { get; set; }
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public bool ClienteAtivo { get; set; }
        public Documento Documento { get; set; }
        public DateTime? DataNascimento { get; set; }
        public string TipoPessoa { get; set; }
        public EGeneroContato? Genero { get; set; }
        public Email Email { get; set; }
        public Telefone Telefone { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }
        public bool ClienteVigente { get; set; }
    }
}