namespace Herval.Emarsys.Sdk.Dtos
{
    public class AnexoEmailDto
    {
        public string NomeArquivo { get; set; }
        public string ArquivoBase64 { get; set; }
    }
}