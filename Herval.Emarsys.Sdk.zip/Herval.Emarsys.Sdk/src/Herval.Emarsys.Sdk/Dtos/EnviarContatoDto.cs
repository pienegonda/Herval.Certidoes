using System.Collections.Generic;
using Herval.Emarsys.Sdk.Enums;

namespace Herval.Emarsys.Sdk.Dtos
{
    public class EnviarContatoDto<T>
    {
        public ENegocio Negocio { get; set; }
        public IEnumerable<T> Contatos { get; set; }
    }
}