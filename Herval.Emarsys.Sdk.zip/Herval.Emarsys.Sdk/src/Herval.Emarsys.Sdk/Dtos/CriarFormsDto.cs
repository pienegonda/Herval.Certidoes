﻿using Herval.Emarsys.Sdk.Enums;
using Herval.ValueObjects.Objects;

namespace Herval.Emarsys.Sdk.Dtos
{
    public class CriarFormsDto
    {
        public string FormsId { get; set; }
        public ENegocio Negocio { get; set; }
        public Email Email { get; set; }
        public Telefone Telefone { get; set; }
        public Documento Documento { get; set; }
    }
}
