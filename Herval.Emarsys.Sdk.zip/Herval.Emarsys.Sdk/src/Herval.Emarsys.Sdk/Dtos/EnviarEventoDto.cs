﻿using Herval.Emarsys.Sdk.Enums;
using System.Collections.Generic;

namespace Herval.Emarsys.Sdk.Dtos
{
    public class EnviarEventoDto
    {
        public string EventoId { get; set; }
        public string DocumentoDestinatario { get; set; }
        public string EmailDestinatario { get; set; }
        public Dictionary<string, string> Dados { get; set; }
        public ENegocio Negocio { get; set; }
        public List<AnexoEmailDto> Anexos { get; set; }
    }
}
