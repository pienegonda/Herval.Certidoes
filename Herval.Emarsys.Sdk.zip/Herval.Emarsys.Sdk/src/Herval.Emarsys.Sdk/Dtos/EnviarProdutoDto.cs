﻿using System.Collections.Generic;
using Herval.Emarsys.Sdk.Enums;

namespace Herval.Emarsys.Sdk.Dtos
{
    public class EnviarProdutoDto
    {
        public ENegocio Negocio { get; set; }
        public IEnumerable<ProdutoDto> Produtos { get; set; }
    }
}
