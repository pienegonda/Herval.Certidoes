using Herval.Emarsys.Sdk.Enums;

namespace Herval.Emarsys.Sdk.Dtos
{
    public abstract class ContatoBaseDto
    {
    }
}