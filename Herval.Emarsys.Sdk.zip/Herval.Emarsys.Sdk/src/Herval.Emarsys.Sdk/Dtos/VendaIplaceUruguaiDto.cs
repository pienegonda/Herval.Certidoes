using System;

namespace Herval.Emarsys.Sdk.Dtos
{
    public class VendaIplaceUruguaiDto : VendaBaseDto
    {
        public string Origem { get; private set; }
        public string OrderId { get; private set; }
        public DateTime DataVenda { get; private set; }
        public string Moeda { get; private set; }
        public string Cliente { get; private set; }
        public string Documento { get; private set; }
        public string Item { get; private set; }
        public decimal PrecoOriginal { get; private set; }
        public decimal Preco { get; private set; }
        public decimal Quantidade { get; private set; }
        public string Cupom { get; private set; }
        public string CategoriaPromocao { get; private set; }
        public string MatriculaVendedor { get; private set; }
        public string NomeVendedor { get; private set; }
        public string NomeLoja { get; private set; }
        public string CidadeLoja { get; private set; }
        public string EstadoLoja { get; private set; }
        public string NumeroNotaFiscal { get; private set; }
        public string TipoPagamento { get; private set; }
        public string PedidoEcommerceId { get; private set; }
        public string Multimeios { get; private set; }

        public VendaIplaceUruguaiDto(
            string origem,
            string orderId,
            DateTime dataVenda,
            string moeda,
            string cliente,
            string documento,
            string item,
            decimal precoOriginal,
            decimal preco,
            decimal quantidade,
            string cupom,
            string categoriaPromocao,
            string matriculaVendedor,
            string nomeVendedor,
            string nomeLoja,
            string cidadeLoja,
            string estadoLoja,
            string numeroNotaFiscal,
            string tipoPagamento,
            string pedidoEcommerceId,
            string multimeios)
        {
            Origem = origem;
            OrderId = orderId;
            DataVenda = dataVenda;
            Moeda = moeda;
            Cliente = cliente;
            Documento = documento;
            Item = item;
            PrecoOriginal = precoOriginal;
            Preco = preco;
            Quantidade = quantidade;
            Cupom = cupom;
            CategoriaPromocao = categoriaPromocao;
            MatriculaVendedor = matriculaVendedor;
            NomeVendedor = nomeVendedor;
            NomeLoja = nomeLoja;
            CidadeLoja = cidadeLoja;
            EstadoLoja = estadoLoja;
            NumeroNotaFiscal = numeroNotaFiscal;
            TipoPagamento = tipoPagamento;
            PedidoEcommerceId = pedidoEcommerceId;
            Multimeios = multimeios;
        }
    }
}
