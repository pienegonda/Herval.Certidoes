using System;

namespace Herval.Emarsys.Sdk.Dtos
{
    public class VendaCorretoraDto : VendaBaseDto
    {

        public string Documento { get; set; }
        public int Filial { get; set; }
        public string Item { get; set; }
        public DateTime InicioVigencia { get; set; }
        public DateTime FimVigencia { get; set; }
        public string NumeroProposta { get; set; }
        public int Quantidade { get; set; }
        public string TipoNegociacao { get; set; }
        public string Ramo { get; set; }
        public decimal Valor { get; set; }
        public decimal Comissao { get; set; }
        public int Parcelas { get; set; }
        public DateTime Renovacao { get; set; }
        public string DescricaoItem { get; set; }
        public string RamoTipo { get; set; }
        public string Seguradora { get; set; }
        public string FormaPagamento { get; set; }

        public VendaCorretoraDto(
            string documento, 
            int filial, 
            string item, 
            DateTime inicioVigencia, 
            DateTime fimVigencia, 
            string numeroProposta, 
            int quantidade, 
            string tipoNegociacao, 
            string ramo, 
            decimal valor, 
            decimal comissao, 
            int parcelas, 
            DateTime renovacao, 
            string descricaoItem, 
            string ramoTipo, 
            string seguradora, 
            string formaPagamento)
        {
            Documento = documento;
            Filial = filial;
            Item = item;
            InicioVigencia = inicioVigencia;
            FimVigencia = fimVigencia;
            NumeroProposta = numeroProposta;
            Quantidade = quantidade;
            TipoNegociacao = tipoNegociacao;
            Ramo = ramo;
            Valor = valor;
            Comissao = comissao;
            Parcelas = parcelas;
            Renovacao = renovacao;
            DescricaoItem = descricaoItem;
            RamoTipo = ramoTipo;
            Seguradora = seguradora;
            FormaPagamento = formaPagamento;
        }
    }
}