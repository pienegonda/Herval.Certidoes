﻿using System.Collections.Generic;
using Herval.Emarsys.Sdk.Enums;

namespace Herval.Emarsys.Sdk.Dtos
{
    public class EnviarVendaDto<T>
    {
        public ENegocio Negocio { get; set; }
        public IEnumerable<T> Vendas { get; set; }
    }
}
