namespace Herval.Emarsys.Sdk.Dtos
{
    public class ProdutoDto
    {
        public string Item { get; private set; }
        public string Nome { get; private set; }
        public string Link { get; private set; }
        public string ImagemLink { get; private set; }
        public decimal Preco { get; private set; }
        public string Categoria { get; private set; }
        public bool Disponivel { get; private set; }
        public string Marca { get; private set; }
        public string Descricao { get; private set; }
        public string ZoomImagemLink { get; private set; }
        public string Cor { get; private set; }
        public decimal? Msrp { get; private set; }
        public string CategoriaIdNivel3 { get; private set; }
        public string CategoriaNomeNivel3 { get; private set; }
        public string CategoriaIdNivel2 { get; private set; }
        public string CategoriaNomeNivel2 { get; private set; }
        public string CategoriaIdNivel1 { get; private set; }
        public string CategoriaNomeNivel1 { get; private set; }
        public decimal? PrecoDesconto { get; private set; }
        public string NumeroFornecedor { get; private set; }
        public string NumeroFornecedor2 { get; private set; }
        public decimal? PrecoLista { get; private set; }
        public decimal? PrecoVenda { get; private set; }
        public int? NumeroParcelas { get; private set; }
        public decimal? PrecoParcela { get; private set; }
        public decimal? ValorParcela { get; private set; }
        public decimal? Estoque { get; private set; }

        public ProdutoDto(
            string item,
            string nome,
            string link,
            string imagemLink,
            decimal preco,
            string categoria,
            bool disponivel,
            string marca,
            string descricao)
        {
            Item = item;
            Nome = nome;
            Link = link;
            ImagemLink = imagemLink;
            Preco = preco;
            Categoria = categoria;
            Disponivel = disponivel;
            Marca = marca;
            Descricao = descricao;
        }

        public ProdutoDto(
            string item,
            string nome,
            string link,
            string imagemLink,
            decimal preco,
            string categoria,
            bool disponivel,
            string marca,
            string descricao,
            string zoomImagemLink,
            string cor,
            decimal? msrp,
            string categoriaIdNivel3,
            string categoriaNomeNivel3,
            string categoriaIdNivel2,
            string categoriaNomeNivel2,
            string categoriaIdNivel1,
            string categoriaNomeNivel1,
            decimal? precoDesconto,
            string numeroFornecedor,
            string numeroFornecedor2,
            decimal? precoLista,
            decimal? precoVenda,
            int? numeroParcelas,
            decimal? precoParcela,
            decimal? valorParcela,
            decimal? estoque)
            : this(item, nome, link, imagemLink, preco, categoria, disponivel, marca, descricao)
        {
            ZoomImagemLink = zoomImagemLink;
            Cor = cor;
            Msrp = msrp;
            CategoriaIdNivel3 = categoriaIdNivel3;
            CategoriaNomeNivel3 = categoriaNomeNivel3;
            CategoriaIdNivel2 = categoriaIdNivel2;
            CategoriaNomeNivel2 = categoriaNomeNivel2;
            CategoriaIdNivel1 = categoriaIdNivel1;
            CategoriaNomeNivel1 = categoriaNomeNivel1;
            PrecoDesconto = precoDesconto;
            NumeroFornecedor = numeroFornecedor;
            NumeroFornecedor2 = numeroFornecedor2;
            PrecoLista = precoLista;
            PrecoVenda = precoVenda;
            NumeroParcelas = numeroParcelas;
            PrecoParcela = precoParcela;
            ValorParcela = valorParcela;
            Estoque = estoque;
        }
    }
}
