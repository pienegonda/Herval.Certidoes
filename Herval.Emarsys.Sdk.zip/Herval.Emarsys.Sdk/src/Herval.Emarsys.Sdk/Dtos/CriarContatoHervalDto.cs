﻿using Herval.Emarsys.Sdk.Enums;
using Herval.ValueObjects.Objects;
using System;

namespace Herval.Emarsys.Sdk.Dtos
{
    public class CriarContatoHervalDto : ContatoBaseDto
    {
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public Email Email { get; set; }
        public DateTime? DataNascimento { get; set; }
        public EGeneroContato? Genero { get; set; }
        public EEstadoCivilContato? EstadoCivil { get; set; }
        public string Endereco { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }
        public EPaisOrigemContato? PaisOrigem { get; set; }
        public Cep CEP { get; set; }
        public Telefone Telefone { get; set; }
        public Documento Documento { get; set; }
        public string DocumentoEstrangeiro { get; set; }
        public int Filhos { get; set; }
        public ECargoContato? CargoEmpresa { get; set; }
        public EEscolaridadeContato? Escolaridade { get; set; }
        public EDepartamentoContato? Departamento { get; set; }
        public EIndustriaContato? Industria { get; set; }
        public Telefone TelefoneEmpresa { get; set; }
        public string FaxEmpresa { get; set; }
        public int NumeroFuncionarios { get; set; }
        public decimal? ReceitaAnual { get; set; }
        public string SiteEmpresa { get; set; }
        public string PrimeiroNomeConjugue { get; set; }
        public DateTime? DataNascimentoConjugue { get; set; }
        public DateTime? Aniversario { get; set; }
        public string EnderecoEmpresa { get; set; }
        public string CEPEmpresa { get; set; }
        public string CidadeEmpresa { get; set; }
        public string EstadoEmpresa { get; set; }
        public EPaisOrigemContato? RegiaoEmpresa { get; set; }
        public decimal? LimiteGlobal { get; set; }
        public decimal? LimiteIplaceHoje { get; set; }
        public decimal? LimiteCDC { get; set; }
        public decimal? LimiteParcela { get; set; }
        public bool? FuncionarioAtivo { get; set; }
        public string MatriculaFuncionario { get; set; }
        public DateTime? DataDemissaoFuncionario { get; set; }
        public bool? AceitaContatoWhatsApp { get; set; }

        public int Idade => DataNascimento.HasValue ? CalcularIdade() : 0;

        private int CalcularIdade()
        {
            return DateTime.Now.Year - DataNascimento.Value.Year -
                   (DateTime.Now.DayOfYear < DataNascimento.Value.DayOfYear ? 1 : 0);
        }
    }
}