﻿namespace Herval.Emarsys.Sdk.Enums
{
    public enum ENegocio
    {
        Taqi = 1,
        Iplace = 2,
        VouLevar = 3,
        HsFinanceira = 4,
        HsConsorcio = 5,
        TaqiCorp = 6,
        IplaceCorp = 7,
        IplaceUY = 8,
        Hlar = 9,
        HTSolutions = 10,
        Herval = 11,
        HQuimica = 12,
        MisterTech = 13,
        UUltis = 14,
        Volis = 15,
        Corretora = 16
    }
}
