﻿namespace Herval.Emarsys.Sdk.Enums
{
    public enum EGeneroContato
    {
        Masculino = 1,
        Feminino = 2,
        PrefiroNaoInformar = 3,
    }
}