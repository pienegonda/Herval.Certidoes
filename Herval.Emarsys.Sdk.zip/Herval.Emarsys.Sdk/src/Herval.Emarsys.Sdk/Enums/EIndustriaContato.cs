﻿namespace Herval.Emarsys.Sdk.Enums
{
    public enum EIndustriaContato
    {
        Agricultura = 1,
        AutomotivoTransporte = 2,
        ConsultoriaOutrosServicos = 3,
        BensDeConsumoPacotados = 4,
        EducacaoPesquisa = 5,
        EntretenimentoLazer = 6,
        ServicosFinanceiros = 7,
        GovernoMilitarSetorPublico = 8,
        HardwareSoftware = 9,
        SaudeFarmaceutica = 10,
        Manufatura = 11,
        MidiaEditorial = 12,
        SemFinsLucrativos = 13,
        VarejoAtacadoECommerce = 14,
        Telecomunicacao = 15,
        TurismoHospitalidade = 16,
        ServicoPublico = 17,
        AgenciaPublicidadeRP = 18
    }
}
