﻿namespace Herval.Emarsys.Sdk.Enums
{
    public enum EEstadoCivilContato
    {
        Solteiro = 1,
        Casado = 2,
        Sociedade = 3,
        Divorciado = 4,
        Viuvo = 5
    }
}