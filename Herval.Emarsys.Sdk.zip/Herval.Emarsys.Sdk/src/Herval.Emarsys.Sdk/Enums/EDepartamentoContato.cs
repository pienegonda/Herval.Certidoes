﻿namespace Herval.Emarsys.Sdk.Enums
{
    public enum EDepartamentoContato
    {
        ECommerce = 1,
        Executivo = 2,
        Financas = 3,
        TecnologiaDaInformacao = 4,
        Investimentos = 5,
        Fabricacao = 6,
        Marketing = 7,
        NovosNegocios = 8,
        NovasMidias = 9,
        Operacoes = 10,
        RelacoesComunicacao = 11,
        PesquisaDesenvolvimento = 12,
        Vendas = 13,
        Telecomunicacoes = 14,
        RecursosHumanos = 15,
        AtendimentoAoCliente = 16,
        Outro = 17
    }
}
