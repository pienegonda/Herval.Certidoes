namespace Herval.Emarsys.Sdk.Enums
{
    public enum EAceitaContatoWhatsApp
    {
        Sim = 1,
        Nao = 2
    }
}