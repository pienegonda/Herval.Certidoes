﻿namespace Herval.Emarsys.Sdk.Enums
{
    public enum ECargoContato
    {
        Administrativo = 1,
        CEO = 2,
        CFO = 3,
        CIO = 4,
        CMO = 5,
        COO = 6,
        CTO = 7,
        PresidenteConselho = 8,
        Consultor = 9,
        Controlador = 10,
        Designer = 11,
        DiretorTISI = 12,
        EquipeTISI = 13,
        Gerente = 14,
        RPMarketing = 15,
        Presidente = 16,
        Jornalista = 17,
        GestaoProdutoMarca = 18,
        VendasDesenvolvimentoNegocios = 19,
        Supervisor = 20,
        IntegradorSistemas = 21,
        VPMarketing = 22,
        VPVendas = 23,
        Autonomo = 24,
        Estagiario = 25,
        Estudante = 26,
        Aposentado = 27,
        Desempregado = 28,
        EmCasa = 29,
        Outro = 30
    }
}
