﻿namespace Herval.Emarsys.Sdk.Enums
{
    public enum EReceitaAnualContato
    {
        MenosDeNoventaENove = 1,
        EntreCemEDuzentosQuarentaENove = 2,
        EntreDuzentosECinquentaEQuatrocentosENoventaENove = 3,
        EntreQuinhentosENovecentosENoventaENove = 4,
        EntreMilEDoisMilQuatrocentosENoventaENove = 5,
        EntreDoisMilQuinhentosENoveMilENovecentosENoventaENove = 6,
        AcimaDeDezMil = 7,
        SemInformacao = 8
    }
}
