namespace Herval.Emarsys.Sdk.Enums
{
    public enum EChaveEnvio
    {
        Email = 3,
        Telefone = 37
    }
}
