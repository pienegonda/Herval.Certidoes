﻿namespace Herval.Emarsys.Sdk.Enums
{
    public enum EEscolaridadeContato
    {
        EnsinoFundamental = 1,
        EscolaAbrangente = 2,
        Aprendizagem = 3,
        EscolaSecundaria = 4,
        Faculdade = 5
    }
}
