﻿namespace Herval.Emarsys.Sdk.Enums
{
    public enum EFilhoContato
    {
        Nenhum = 1,
        Um = 2,
        Dois = 3,
        Tres = 4,
        QuatroOuMais = 5
    }
}
