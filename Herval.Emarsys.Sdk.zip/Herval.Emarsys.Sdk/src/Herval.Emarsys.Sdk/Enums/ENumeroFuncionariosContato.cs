﻿namespace Herval.Emarsys.Sdk.Enums
{
    public enum ENumeroFuncionariosContato
    {
        EntreUmENove = 1,
        EntreDezEQuarentaENove = 2,
        EntreCinquentaENoventaENove = 3,
        EntreCemEDuzentosQuarentaENove = 4,
        EntreDuzentosECinquentaEQuatrocentosENoventaENove = 5,
        EntreQuinhentosENovecentosENoventaENove = 6,
        EntreMilEDoisMilQuatrocentosENoventaENove = 7,
        EntreDoisMilQuinhentosENoveMilENovecentosENoventaENove = 8,
        AcimaDeDezMil = 9,
        SemInformacao = 10
    }
}
