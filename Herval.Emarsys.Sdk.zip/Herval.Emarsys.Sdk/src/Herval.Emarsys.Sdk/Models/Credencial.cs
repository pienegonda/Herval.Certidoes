namespace Herval.Emarsys.Sdk.Models
{
    public class Credencial
    {
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string TokenVenda { get; set; }
        public string MerchantId { get; set; }
        public string UsuarioFTP { get; set; }
        public string SenhaFTP { get; set; }
        public string BU { get; set; }
    }
}
