using Herval.Emarsys.Sdk.Dtos;
using Herval.Emarsys.Sdk.Interfaces;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace Herval.Emarsys.Sdk.Exporters
{
    /// <summary>
    /// Exportador de produtos para formato CSV
    /// </summary>
    public class CsvProdutoExporter : IFileExporter<ProdutoDto>
    {
        /// <summary>
        /// Gera um arquivo CSV em formato de bytes a partir de uma coleção de produtos
        /// </summary>
        /// <param name="produtos">Coleção de produtos a serem exportados</param>
        /// <returns>Array de bytes representando o arquivo CSV gerado</returns>
        public byte[] GerarArquivoCSVEmBytes(IEnumerable<ProdutoDto> produtos)
        {
            using (var memoryStream = new MemoryStream())
            using (var streamWriter = new StreamWriter(memoryStream, Encoding.UTF8))
            {
                // Escrever o cabeçalho do CSV
                streamWriter.WriteLine(CriarCabecalhoCsv());

                // Escrever as linhas de dados
                foreach (var produto in produtos)
                {
                    streamWriter.WriteLine(FormatarLinhaCsv(produto));
                }

                streamWriter.Flush();
                return memoryStream.ToArray();
            }
        }

        /// <summary>
        /// Cria o cabeçalho do CSV com os nomes das colunas
        /// </summary>
        private static string CriarCabecalhoCsv()
        {
            return string.Join(",",
                "item",
                "title",
                "link",
                "image",
                "price",
                "category",
                "available",
                "brand",
                "description",
                "zoom_image",
                "c_color",
                "msrp",
                "c_level_3_category_id",
                "c_level_3_name",
                "c_level_2_category_id",
                "c_level_2_name",
                "c_level_1_category_id",
                "c_level_1_name",
                "c_discount_price",
                "c_part_number",
                "c_part_number2",
                "c_regular_price",
                "c_sale_price",
                "c_installment_number",
                "c_installment_price",
                "c_installment_value",
                "c_estoque"
            );
        }

        /// <summary>
        /// Formata uma linha do CSV a partir de um objeto ProdutoDto
        /// </summary>
        private static string FormatarLinhaCsv(ProdutoDto produto)
        {
            return string.Format(
                CultureInfo.InvariantCulture,
                "\"{0}\",\"{1}\",\"{2}\",\"{3}\",{4},\"{5}\",{6},\"{7}\",\"{8}\",\"{9}\",\"{10}\",{11},\"{12}\",\"{13}\",\"{14}\",\"{15}\",\"{16}\",\"{17}\",{18},\"{19}\",\"{20}\",{21},{22},{23},{24},{25},{26}",
                produto.Item?.Replace("\"", "\"\""),
                produto.Nome?.Replace("\"", "\"\""),
                produto.Link?.Replace("\"", "\"\""),
                produto.ImagemLink?.Replace("\"", "\"\""),
                produto.Preco.ToString("0.00", CultureInfo.InvariantCulture),
                produto.Categoria?.Replace("\"", "\"\""),
                produto.Disponivel.ToString().ToLowerInvariant(),
                produto.Marca?.Replace("\"", "\"\""),
                produto.Descricao?.Replace("\"", "\"\""),
                produto.ZoomImagemLink?.Replace("\"", "\"\""),
                produto.Cor?.Replace("\"", "\"\""),
                produto.Msrp.HasValue ? produto.Msrp.Value.ToString("0.00", CultureInfo.InvariantCulture) : "",
                produto.CategoriaIdNivel3?.Replace("\"", "\"\""),
                produto.CategoriaNomeNivel3?.Replace("\"", "\"\""),
                produto.CategoriaIdNivel2?.Replace("\"", "\"\""),
                produto.CategoriaNomeNivel2?.Replace("\"", "\"\""),
                produto.CategoriaIdNivel1?.Replace("\"", "\"\""),
                produto.CategoriaNomeNivel1?.Replace("\"", "\"\""),
                produto.PrecoDesconto.HasValue ? produto.PrecoDesconto.Value.ToString("0.00", CultureInfo.InvariantCulture) : "",
                produto.NumeroFornecedor?.Replace("\"", "\"\""),
                produto.NumeroFornecedor2?.Replace("\"", "\"\""),
                produto.PrecoLista.HasValue ? produto.PrecoLista.Value.ToString("0.00", CultureInfo.InvariantCulture) : "",
                produto.PrecoVenda.HasValue ? produto.PrecoVenda.Value.ToString("0.00", CultureInfo.InvariantCulture) : "",
                produto.NumeroParcelas.HasValue ? produto.NumeroParcelas.Value.ToString() : "",
                produto.PrecoParcela.HasValue ? produto.PrecoParcela.Value.ToString("0.00", CultureInfo.InvariantCulture) : "",
                produto.ValorParcela.HasValue ? produto.ValorParcela.Value.ToString("0.00", CultureInfo.InvariantCulture) : "",
                produto.Estoque.HasValue ? produto.Estoque.Value.ToString("0.00", CultureInfo.InvariantCulture) : ""
            );
        }
    }
}
