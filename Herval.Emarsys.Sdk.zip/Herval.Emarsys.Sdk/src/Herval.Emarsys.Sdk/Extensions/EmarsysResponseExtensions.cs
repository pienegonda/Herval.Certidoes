using System.Collections.Generic;
using System.Linq;
using Herval.Emarsys.Sdk.Responses;

namespace Herval.Emarsys.Sdk.Extensions
{
    /// <summary>
    /// Métodos de extensão para trabalhar com respostas da API Emarsys
    /// </summary>
    public static class EmarsysResponseExtensions
    {
        public static bool TemErros(this EmarsysResponse response)
        {
            return response.Data?.Errors != null && response.Data.Errors.Any();
        }

        public static List<string> ObterMensagensErro(this EmarsysResponse response)
        {
            var mensagens = new List<string>();

            if (!response.TemErros())
                return mensagens;

            foreach (var error in response.Data.Errors)
            {
                var identifier = error.Key;
                var errorDetails = error.Value;

                foreach (var detail in errorDetails)
                {
                    mensagens.Add($"Erro para o item {identifier}: {detail.Key} - {detail.Value}");
                }
            }

            return mensagens;
        }

        public static Dictionary<string, List<string>> ObterErrosPorIdentificador(this EmarsysResponse response)
        {
            var erros = new Dictionary<string, List<string>>();

            if (!response.TemErros())
                return erros;

            foreach (var error in response.Data.Errors)
            {
                var identifier = error.Key;
                var errorDetails = error.Value;

                if (!erros.ContainsKey(identifier))
                    erros[identifier] = new List<string>();

                foreach (var detail in errorDetails)
                {
                    erros[identifier].Add($"{detail.Key} - {detail.Value}");
                }
            }

            return erros;
        }
    }
}
