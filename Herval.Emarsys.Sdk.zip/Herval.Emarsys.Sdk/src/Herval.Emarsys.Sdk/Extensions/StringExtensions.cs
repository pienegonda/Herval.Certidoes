namespace Herval.Emarsys.Sdk.Extensions
{
    public static class StringExtensions
    {
        internal static string RemoveHeaderBase64(this string base64)
        {
            if (string.IsNullOrWhiteSpace(base64))
                return base64;

            var commaIndex = base64.IndexOf(',');

            if (commaIndex < 0)
                return base64;

            return base64[(commaIndex + 1)..];
        }
    }
}
