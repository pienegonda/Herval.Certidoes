﻿namespace Herval.Emarsys.Sdk.Extensions
{
    public static class BooleanEmarsysExtensions
    {
        internal static string ToBooleanEmarsys(this bool valor)
        {
            return valor ? "1" : "2";
        }
    }
}
