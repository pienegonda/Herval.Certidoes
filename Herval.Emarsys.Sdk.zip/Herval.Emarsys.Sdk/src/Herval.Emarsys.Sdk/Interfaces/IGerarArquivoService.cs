using Herval.Emarsys.Sdk.Dtos;

namespace Herval.Emarsys.Sdk.Interfaces
{
    public interface IGerarArquivoService
    {
        byte[] GerarArquivoCsv<T>(EnviarVendaDto<T> venda) where T : VendaBaseDto;
    }
}