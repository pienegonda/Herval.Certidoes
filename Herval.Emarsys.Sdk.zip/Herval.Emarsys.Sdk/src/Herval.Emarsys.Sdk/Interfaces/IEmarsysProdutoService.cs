using System.Threading;
using System.Threading.Tasks;
using Herval.Emarsys.Sdk.Dtos;

namespace Herval.Emarsys.Sdk.Interfaces
{
    public interface IEmarsysProdutoService
    {
        Task EnviarProdutoAsync(EnviarProdutoDto enviarProdutoDto, CancellationToken cancellationToken);
    }
}
