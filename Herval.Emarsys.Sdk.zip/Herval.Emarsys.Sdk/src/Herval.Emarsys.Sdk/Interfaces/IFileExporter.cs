using System.Collections.Generic;

namespace Herval.Emarsys.Sdk.Interfaces
{
/// <summary>
/// Interface para exportadores de arquivos
/// </summary>
    public interface IFileExporter<T>
    {
        /// <summary>
        /// Gera um arquivo em formato de bytes a partir de uma coleção de dados
        /// </summary>
        /// <param name="data">Dados a serem exportados</param>
        /// <returns>Array de bytes representando o arquivo gerado</returns>
        byte[] GerarArquivoCSVEmBytes(IEnumerable<T> data);
    }
}
