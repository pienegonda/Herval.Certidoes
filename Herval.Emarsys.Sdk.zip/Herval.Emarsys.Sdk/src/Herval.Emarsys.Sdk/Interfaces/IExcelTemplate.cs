using System;
using Herval.Emarsys.Sdk.Dtos;

namespace Herval.Emarsys.Sdk.Interfaces
{
    public interface IExcelTemplate<T> where T : VendaBaseDto
    {
        string WorksheetName { get; }
        string[] SubHeaders { get; }
        Func<T, string>[] Mappers { get; }
    }
}