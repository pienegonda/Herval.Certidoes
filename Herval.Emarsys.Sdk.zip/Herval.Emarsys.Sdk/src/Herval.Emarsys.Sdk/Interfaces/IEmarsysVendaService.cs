﻿using Herval.Emarsys.Sdk.Dtos;
using System.Threading;
using System.Threading.Tasks;

namespace Herval.Emarsys.Sdk.Interfaces
{
    public interface IEmarsysVendaService
    {
        Task EnviarVendaAsync<T>(EnviarVendaDto<T> enviarVendaDto, CancellationToken cancellationToken) where T : VendaBaseDto;
    }
}
