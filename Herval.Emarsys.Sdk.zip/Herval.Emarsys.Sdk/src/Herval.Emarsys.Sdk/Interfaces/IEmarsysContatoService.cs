using Herval.Emarsys.Sdk.Dtos;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Herval.Emarsys.Sdk.Interfaces
{
    public interface IEmarsysContatoService
    {
        Task CriarContatoAsync<T>(EnviarContatoDto<T> criarContatoDto, CancellationToken cancellationToken) where T : ContatoBaseDto;
        Task CriarFormsAsync(CriarFormsDto criarFormsDto, CancellationToken cancellationToken);
        Task AtualizarContatoAsync(AtualizarContatoDto atualizarContatoDto, CancellationToken cancellationToken);
    }
}
