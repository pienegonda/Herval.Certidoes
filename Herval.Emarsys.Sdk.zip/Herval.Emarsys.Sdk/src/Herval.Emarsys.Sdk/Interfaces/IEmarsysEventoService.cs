using System.Threading;
using System.Threading.Tasks;
using Herval.Emarsys.Sdk.Dtos;

namespace Herval.Emarsys.Sdk.Interfaces
{
    public interface IEmarsysEventoService
    {
        Task EnviarEventoAsync(EnviarEventoDto enviarEventoDto, CancellationToken cancellationToken);
    }
}
