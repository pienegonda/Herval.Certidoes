using System;
using System.Collections.Generic;

namespace Herval.Emarsys.Sdk.Interfaces
{
    public interface IExcelService
    {
        byte[] ExportarParaCsv<T>(
                string worksheetName,
                IEnumerable<T> data,
                IEnumerable<string> subHeaders,
                IEnumerable<Func<T, string>> mappers);
    }
}