﻿namespace Herval.Emarsys.Sdk.Constants
{
    public static class ChaveContato
    {
        public const string Nome = "1";
        public const string Sobrenome = "2";
        public const string Email = "3";
        public const string DataNascimento = "4";
        public const string Genero = "5";
        public const string EstadoCivil = "6";
        public const string AceitaContatoWhatsApp = "13506";

        public const string Endereco = "10";
        public const string Cidade = "11";
        public const string Estado = "12";
        public const string CEP = "13";
        public const string Regiao = "14";
        public const string TelefoneFixo = "15";
        public const string Fax = "16";
        public const string CargoEmpresa = "17";
        public const string Empresa = "18";

        public const string Celular = "37";
        public const string DocumentoHerval = "13540";
        public const string DocumentoIplace = "12908";
        public const string DocumentoIplaceCorp = "13481";
        public const string DocumentoIplaceUY = "13176";
        public const string DocumentoTaqi = "12939";
        public const string DocumentoTaqiCorp = "13623";
        public const string DocumentoHSConsorcio = "12969";
        public const string DocumentoHSFinanceira = "12968";
        public const string DocumentoHTSolutions = "13624";
        public const string DocumentoVoulevar = "12967";
        public const string DocumentoVolis = "12983";
        public const string DocumentoUultis = "13185";
        public const string DocumentoMistertech = "13179";
        public const string IdadeHerval = "13636";
        public const string IdadeIplace = "12858";
        public const string IdadeIplaceCorp = "13640";
        public const string IdadeIplaceUY = "13177";
        public const string IdadeTaqi = "12937";
        public const string IdadeTaqiCorp = "13642";
        public const string IdadeHSConsorcio = "13457";
        public const string IdadeHSFinanceira = "13656";
        public const string IdadeHTSolutions = "13639";
        public const string IdadeVoulevar = "13645";
        public const string IdadeVolis = "12985";
        public const string IdadeUultis = "13184";
        public const string IdadeMistertech = "13178";

        // Financeira
        public const string Filhos = "7";
        public const string Escolaridade = "8";
        public const string Departamento = "19";
        public const string Industria = "20";
        public const string TelefoneEmpresa = "21";
        public const string FaxEmpresa = "22";
        public const string NumeroFuncionarios = "23";
        public const string ReceitaAnual = "24";
        public const string SiteEmpresa = "25";
        public const string PrimeiroNomeConjugue = "38";
        public const string DataNascimentoConjugue = "39";
        public const string Aniversario = "40";
        public const string EnderecoEmpresa = "41";
        public const string CEPEmpresa = "42";
        public const string CidadeEmpresa = "43";
        public const string EstadoEmpresa = "44";
        public const string RegiaoEmpresa = "45";
        public const string LimiteGlobal = "14179";
        public const string LimiteIplaceHoje = "12989";
        public const string LimiteCDC = "14176";
        public const string LimiteParcela = "14177";

        // Funcionario
        public const string FuncionarioAtivo = "13660";
        public const string MatriculaFuncionario = "15108";
        public const string DataDemissaoFuncionario = "15425";

        // Clientes Corretora
        public const string CodigoCliente = "11869";
        public const string ClienteAtivo = "11866";
        public const string DocumentoCliente = "7948";
        public const string TipoPessoa = "11868";
        public const string ClienteVigente = "11867";
    }
}
